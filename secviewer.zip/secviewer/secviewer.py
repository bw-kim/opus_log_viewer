#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
secviewer.py — 리눅스 침해사고 보안 로그 뷰어

SSH 침입 → 명령 실행 → DB 덤프 → 파일 전송(유출) 흐름을 여러 로그에서 모아
타임라인 / 공격자 IP / 세션 뷰가 있는 단일 HTML 리포트로 만든다.
Python 3.8+ 표준 라이브러리만 사용하므로 서버에 이 파일 하나만 올려 실행하면 된다.

  sudo python3 secviewer.py                         # 현재 서버(/) 분석 → secview_report.html
  python3 secviewer.py --root ./evidence            # 수집해 온 로그(/ 디렉터리 구조 그대로) 분석
  sudo python3 secviewer.py --serve 8080            # 분석 후 http://127.0.0.1:8080 으로 보기
  python3 secviewer.py --root ./evidence --json out.json   # JSON 으로도 저장

읽는 로그
  SSH/계정   /var/log/auth.log*, /var/log/secure*  (없으면 journalctl)
  명령       /var/log/audit/audit.log* (EXECVE), ~/.bash_history 등, sudo COMMAND
  로그인기록 /var/log/wtmp*, /var/log/btmp*
  DB         MySQL general log, PostgreSQL 로그
  파일전송   SFTP(internal-sftp, LogLevel VERBOSE), vsftpd/xferlog, scp/curl/wget/rsync 명령
"""
import argparse
import datetime as dt
import glob
import gzip
import http.server
import ipaddress
import json
import os
import re
import shutil
import socket
import socketserver
import struct
import subprocess
import sys
import time
from collections import Counter, defaultdict

SEVS = ['info', 'low', 'med', 'high', 'crit']
SEV_RANK = {s: i for i, s in enumerate(SEVS)}
MONTHS = {m: i for i, m in enumerate('Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split(), 1)}
UNSET_AUID = {'4294967295', '-1', 'unset'}
TZ_ABBR = {'UTC': 0, 'GMT': 0, 'KST': 540, 'JST': 540, 'CST': 480, 'CET': 60, 'CEST': 120,
           'EST': -300, 'EDT': -240, 'PST': -480, 'PDT': -420}

CATS = {
    'auth':         'SSH 인증',
    'session':      '세션',
    'cmd':          '명령어',
    'db':           'DB 접근·덤프',
    'transfer':     '파일 전송',
    'persist':      '지속성 확보',
    'antiforensic': '흔적 삭제',
    'exec':         '악성 실행',
    'privesc':      '권한 상승',
    'recon':        '정찰',
}

# ───────────────────────── 명령어 분류 규칙 ─────────────────────────
# 명령 위치(줄 처음, 파이프/세미콜론 뒤, sudo/nohup 뒤)에 나온 실행 파일만 잡는다.
_HEAD = r'(?:^|[;&|`(]\s*|\$\(\s*|\bsudo\s+(?:-\S+\s+(?:\w+\s+)?)*|\bnohup\s+|\btime\s+|\bexec\s+)(?:\S*/)?'


def _c(names):
    return _HEAD + r'(?:' + names + r')(?=\s|$|;|\||\))'


# (분류, 기본 위험도, 라벨, 정규식) — 위에서부터 우선순위
RULES = [(c, s, l, re.compile(p)) for c, s, l, p in [
    ('antiforensic', 'crit', '흔적 삭제',
     r'history\s+-[cw]|unset\s+HISTFILE|HISTFILE=/dev/null|HISTSIZE=0|set\s+\+o\s+history|\bshred\b'
     r'|\brm\s+(?:-\S+\s+)*\S*(?:_history|/var/log/)|(?:^|[\s;])(?:>|cat\s+/dev/null\s*>)\s*/var/log/'
     r'|\btruncate\s.*(?:/var/log|_history)|journalctl\s.*--(?:vacuum|rotate)|\bauditctl\s+-D'
     r'|(?:service\s+auditd\s+stop|systemctl\s+stop\s+(?:auditd|rsyslog|syslog))|\btouch\s+-[a-z]*[rdt]\b'),
    ('exec', 'crit', '리버스 셸 의심',
     r'\b(?:ba|z)?sh\s+-i\b.*/dev/(?:tcp|udp)/|/dev/(?:tcp|udp)/\S+.*[0-2]>&[0-2]|\bnc(?:at)?\s(?:.*\s)?-[ec]\s'
     r'|\bmkfifo\b.*\bnc\b|\bsocat\b.*\bexec:|pty\.spawn|socket\.socket\(.*connect'),
    ('db', 'crit', 'DB 덤프',
     _c(r'mysqldump|mariadb-dump|mydumper|xtrabackup|mariabackup|pg_dump|pg_dumpall|pg_basebackup'
        r'|mongodump|mongoexport|expdp|exp')
     + r'|redis-cli\b.*(?:--rdb\b|\bbgsave\b|\bsave\b)|sqlite3\b.*\.(?:dump|backup)|(?i:into\s+(?:out|dump)file)'
       r'|(?i:\bcopy\b.+\bto\s+(?:\'|stdout|program))'
       r'|\b(?:cp|scp|rsync|tar)\b.*(?:/var/lib/(?:mysql|postgresql|pgsql|mongodb|redis)\b|\.(?:ibd|rdb|sqlite3?)\b)'),
    ('transfer', 'med', '파일 전송',
     _c(r'scp|sftp|rsync|wget|curl|ftp|lftp|tftp|nc|ncat|netcat|socat|rclone|smbclient|axel|aria2c|azcopy|gsutil')
     + r'|/dev/tcp/|\baws\s+s3\s+(?:cp|sync|mv)\b|python[23]?\s+-m\s+(?:http\.server|SimpleHTTPServer)|\bphp\s+-S\b'),
    ('persist', 'high', '지속성 확보',
     _c(r'useradd|adduser|usermod|chpasswd|visudo|passwd') + r'|' + _c(r'crontab') + r'(?!\s+-l\b)'
     r'|authorized_keys|/etc/(?:rc\.local|cron\S*|sudoers\S*|systemd/system/\S+|ld\.so\.preload|profile\.d/)'
     r'|systemctl\s+enable|>>?\s*\S*\.(?:bashrc|bash_profile|profile)\b'),
    ('exec', 'high', '악성 실행 의심',
     r'\b(?:ba)?sh\s+-i\b|/dev/(?:tcp|udp)/|python[23]?\s+-c|perl\s+-e|ruby\s+-e|php\s+-r|base64\s+(?:-d|--decode)'
     r'|\bchmod\s+(?:[ugoa]*\+x|0?7[0-7]{2})\b|\|\s*(?:ba|z)?sh\b|\bmkfifo\b|\bnohup\b|\bLD_PRELOAD='
     r'|(?:^|[;&|]\s*)\./\S+|(?:^|[;&|]\s*)/(?:tmp|dev/shm|var/tmp)/\S+|\bxmrig\b'),
    ('recon', 'high', '자격증명 탐색',
     r'(?:cat|less|more|head|tail|grep|strings|vi|vim|nano)\b.*(?:/etc/shadow|wp-config\.php|config\.php|\.env\b'
     r'|\.my\.cnf|\.pgpass|id_rsa|id_ed25519|credentials|\.aws/|database\.yml|settings\.py)'),
    ('privesc', 'med', '권한 상승',
     _c(r'sudo|su|pkexec|doas') + r'|chmod\s+(?:[ugoa]*\+s|[2-7][0-7]{3})\b|\bsetcap\b'),
    ('db', 'med', 'DB 접속', _c(r'mysql|mariadb|psql|mongo|mongosh|redis-cli|sqlplus|sqlite3|clickhouse-client')),
    ('cmd', 'low', '압축·스테이징', _c(r'tar|zip|7z|7za|rar|gzip|bzip2|xz|split')),
    ('recon', 'low', '정찰',
     _c(r'whoami|id|uname|hostname|ifconfig|netstat|ss|ps|w|who|last|lastlog|lsof|env|arp|route|getent')
     + r'|cat\s+/etc/(?:passwd|group|hosts|issue|\S*release)|\bfind\s.*-perm\s+(?:[-/]?[246]000|-u=s)|\bip\s+(?:a|addr|r|route|neigh)\b|crontab\s+-l|sudo\s+-l'),
]]

_ARG_REMOTE = re.compile(r'^[^/\s]*:')  # host:path, user@host:path


def transfer_detail(cmd):
    """파일 전송 명령의 방향(유출/반입)을 구분해 (위험도, 설명)을 돌려준다."""
    if re.search(r'\bscp\b(?:\s+-\S+)*\s+-[A-Za-z]*f(?:\s|$)', cmd):
        return 'crit', 'scp 원격 다운로드 (서버 → 외부 유출)'
    if re.search(r'\bscp\b(?:\s+-\S+)*\s+-[A-Za-z]*t(?:\s|$)', cmd):
        return 'high', 'scp 원격 업로드 (외부 → 서버 반입)'
    if re.search(r'\bcurl\b.*(?:\s-T\s|--upload-file|\s-F\s|--form\b|--data(?:-binary)?\s+@|\s-d\s*@)', cmd):
        return 'crit', 'curl 업로드 (외부 유출)'
    if re.search(r'\b(?:rclone|azcopy|gsutil)\b|\baws\s+s3\s', cmd):
        return 'crit', '클라우드 스토리지 전송'
    for seg in re.split(r'[|;&]', cmd):
        toks = seg.split()
        idx = next((i for i, t in enumerate(toks) if re.search(r'(?:^|/)(?:scp|rsync)$', t)), None)
        if idx is None:
            continue
        args = [t for t in toks[idx + 1:] if not t.startswith('-')]
        if args and _ARG_REMOTE.match(args[-1]):
            return 'crit', '외부 서버로 전송 (유출)'
        if any(_ARG_REMOTE.match(a) for a in args[:-1]):
            return 'high', '외부 서버에서 반입'
    if re.search(r'\bsftp\b', cmd):
        return 'high', 'SFTP 접속'
    if re.search(r'\b(?:nc|ncat|netcat|socat)\b|/dev/tcp/', cmd):
        return 'high', '원시 소켓 전송 (nc/socat)'
    if re.search(r'http\.server|SimpleHTTPServer|php\s+-S', cmd):
        return 'high', '웹서버로 파일 노출'
    if re.search(r'\b(?:wget|curl|axel|aria2c|tftp|ftp|lftp)\b', cmd):
        return 'high', '외부 파일 다운로드'
    return 'high', '파일 전송'


def classify(cmd):
    hits = [(c, s, l) for c, s, l, rx in RULES if rx.search(cmd)]
    if not hits:
        return 'cmd', 'info', []
    labels, best = [], 0
    for _, s, l in hits:
        if l not in labels:
            labels.append(l)
        best = max(best, SEV_RANK[s])
    if '파일 전송' in labels:
        tsev, tlabel = transfer_detail(cmd)
        labels.insert(labels.index('파일 전송') + 1, tlabel)
        best = max(best, SEV_RANK[tsev])
    return hits[0][0], SEVS[best], labels


# ───────────────────────── 공통 유틸 ─────────────────────────
SYSLOG_RE = re.compile(
    r'^(?:<\d+>)?(?:(?P<bsd>[A-Z][a-z]{2}\s+\d{1,2}\s+\d\d:\d\d:\d\d)'
    r'|(?P<iso>\d{4}-\d\d-\d\d[T ]\d\d:\d\d:\d\d(?:[.,]\d+)?(?:Z|[+-]\d\d:?\d\d)?))'
    r'\s+(?P<host>\S+)\s+(?P<prog>[^\s\[:]+)(?:\[(?P<pid>\d+)\])?:\s?(?P<msg>.*)$')
ISO_RE = re.compile(r'^(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d):(\d\d)(?:[.,](\d+))?\s*(Z|[+-]\d\d:?\d\d|[+-]\d\d)?$')


def open_text(path):
    if path.endswith('.gz'):
        return gzip.open(path, 'rt', encoding='utf-8', errors='replace')
    return open(path, 'r', encoding='utf-8', errors='replace')


def rotation_key(path):
    """오래된 로테이션 파일부터: auth.log.4.gz → … → auth.log.1 → auth.log"""
    m = re.search(r'\.(\d+)(?:\.gz)?$', path)
    if m:
        return (0, -int(m.group(1)), '')
    m = re.search(r'-(\d{8})(?:\.gz)?$', path)
    if m:
        return (0, 0, m.group(1))
    return (1, 0, '')


def clean_ip(ip):
    if not ip:
        return None
    ip = ip.strip('[]')
    if ip.startswith('::ffff:'):
        ip = ip[7:]
    return ip


def is_private(ip):
    try:
        a = ipaddress.ip_address(ip)
        return a.is_private or a.is_loopback or a.is_link_local
    except ValueError:
        return True


def human_bytes(n):
    n = float(n)
    for u in ('B', 'KB', 'MB', 'GB', 'TB'):
        if n < 1024 or u == 'TB':
            return f'{n:.0f} {u}' if u == 'B' else f'{n:.1f} {u}'
        n /= 1024


def tz_from_str(s):
    if not s or s == 'local':
        return dt.datetime.now().astimezone().tzinfo
    if s.upper() in TZ_ABBR:
        return dt.timezone(dt.timedelta(minutes=TZ_ABBR[s.upper()]))
    m = re.fullmatch(r'([+-])(\d{1,2}):?(\d\d)?', s)
    if not m:
        raise argparse.ArgumentTypeError(f'시간대 형식 오류: {s} (예: +09:00, UTC, local)')
    mins = int(m.group(2)) * 60 + int(m.group(3) or 0)
    return dt.timezone(dt.timedelta(minutes=-mins if m.group(1) == '-' else mins))


# auditd 레코드
AUDIT_HDR = re.compile(r'type=(?P<type>\S+) msg=audit\((?P<ts>\d+\.\d+):(?P<serial>\d+)\):\s?(?P<body>.*)$')
KV_RE = re.compile(r'(\w+)=("(?:[^"\\]|\\.)*"|\'[^\']*\'|[^\s\x1d]+)')
HEXRE = re.compile(r'(?:[0-9A-F]{2})+')


def audit_kv(body):
    kv = {}
    for k, v in KV_RE.findall(body):
        if v.startswith("'") and k == 'msg':
            for k2, v2 in KV_RE.findall(v[1:-1]):
                kv.setdefault(k2, v2)
            continue
        kv.setdefault(k, v)
    return kv


def audit_str(v, hexok=True):
    if v is None:
        return None
    if len(v) >= 2 and v[0] == v[-1] and v[0] in '"\'':
        return v[1:-1]
    if hexok and HEXRE.fullmatch(v):
        try:
            return bytes.fromhex(v).decode('utf-8', 'replace').replace('\x00', ' ').strip()
        except ValueError:
            pass
    return v


def shell_join(args):
    out = []
    for a in args:
        if a == '' or re.search(r'[\s"\'$`\\|&;<>()*?]', a):
            out.append("'" + a.replace("'", "'\\''") + "'")
        else:
            out.append(a)
    return ' '.join(out)


# ───────────────────────── 분석기 ─────────────────────────
class Analyzer:
    def __init__(self, root, tz, year=None, audit_all=False, use_journal=True, since=None):
        self.root = os.path.abspath(root)
        self.tz = tz
        self.year = year
        self.audit_all = audit_all
        self.use_journal = use_journal
        self.since = since
        self.events = []
        self.sources = []
        self.notes = []
        self.hosts = Counter()
        self.seq = 0
        self.uid_names = {}
        self.uid0_alias = set()
        self.has_auth = False

    # ── 기본 ──
    def rel(self, path):
        r = os.path.relpath(path, self.root).replace('\\', '/')
        return '/' + r if not r.startswith('/') else r

    def paths(self, *patterns):
        out = set()
        for p in patterns:
            for x in glob.glob(os.path.join(self.root, p)):
                if os.path.isfile(x):
                    out.add(x)
        base = lambda x: re.sub(r'(?:\.\d+|-\d{8})?(?:\.gz)?$', '', x)
        return sorted(out, key=lambda x: (base(x), rotation_key(x)))

    def add(self, ts, cat, sev, msg, **kw):
        self.seq += 1
        e = {'ts': ts, 'cat': cat, 'sev': sev, 'msg': msg, 'seq': self.seq}
        for k, v in kw.items():
            if v is not None and v != '' and v != []:
                e[k] = v
        self.events.append(e)
        return e

    def source(self, path, kind, before):
        self.sources.append({'path': path, 'kind': kind, 'events': len(self.events) - before})

    def safe_open(self, path):
        try:
            return open_text(path)
        except PermissionError:
            self.notes.append(f'읽기 권한 없음: {self.rel(path)} — sudo 로 실행하세요')
        except OSError as ex:
            self.notes.append(f'열기 실패: {self.rel(path)} ({ex})')
        return None

    def ts_bsd(self, s, ref_epoch):
        try:
            mon, day, hms = s.split()
            h, mi, se = map(int, hms.split(':'))
            ref = dt.datetime.fromtimestamp(ref_epoch, self.tz)
            year = self.year or ref.year
            d = dt.datetime(year, MONTHS[mon], int(day), h, mi, se, tzinfo=self.tz)
            if not self.year and d.timestamp() > ref_epoch + 2 * 86400:
                d = d.replace(year=year - 1)
            return d.timestamp()
        except (ValueError, KeyError):
            return None

    def ts_iso(self, s, tz=None):
        m = ISO_RE.match(s.strip())
        if not m:
            return None
        y, mo, d, h, mi, se, frac, off = m.groups()
        if off is None:
            tzinfo = tz or self.tz
        elif off == 'Z':
            tzinfo = dt.timezone.utc
        else:
            digits = off[1:].replace(':', '')
            mins = int(digits[:2]) * 60 + int(digits[2:4] or 0)
            tzinfo = dt.timezone(dt.timedelta(minutes=-mins if off[0] == '-' else mins))
        us = int((frac or '0')[:6].ljust(6, '0'))
        try:
            return dt.datetime(int(y), int(mo), int(d), int(h), int(mi), int(se), us, tzinfo=tzinfo).timestamp()
        except ValueError:
            return None

    def run(self):
        self.load_passwd()
        self.scan_auth()
        self.scan_audit()
        self.scan_history()
        self.scan_wtmp()
        self.scan_mysql()
        self.scan_postgres()
        self.scan_ftp()
        if self.since:
            self.events = [e for e in self.events if e['ts'] is None or e['ts'] >= self.since]
        return self.correlate()

    def load_passwd(self):
        p = os.path.join(self.root, 'etc/passwd')
        if not os.path.isfile(p):
            return
        f = self.safe_open(p)
        if not f:
            return
        with f:
            for line in f:
                parts = line.split(':')
                if len(parts) >= 3:
                    self.uid_names.setdefault(parts[2], parts[0])
                    if parts[2] == '0' and parts[0] != 'root':
                        self.uid0_alias.add(parts[0])
                        self.notes.append(f'/etc/passwd 에 UID 0 계정 존재: {parts[0]} (백도어 계정 의심)')

    def uname(self, uid):
        if uid is None or uid in UNSET_AUID:
            return None
        return self.uid_names.get(uid, f'uid={uid}')

    # ── SSH / 인증 로그 ──
    def scan_auth(self):
        files = self.paths('var/log/auth.log*', 'var/log/secure*')
        self.sftp_pids = {}
        for p in files:
            f = self.safe_open(p)
            if not f:
                continue
            self.has_auth = True
            before = len(self.events)
            with f:
                self.auth_lines(f, os.path.getmtime(p), self.rel(p))
            self.source(self.rel(p), 'SSH/계정', before)
        if not self.has_auth and self.root == os.path.abspath('/') and self.use_journal and shutil.which('journalctl'):
            cmd = ['journalctl', '-o', 'short-iso', '--no-pager', '-q']
            for t in ('sshd', 'sudo', 'su', 'useradd', 'usermod', 'userdel', 'passwd', 'chpasswd',
                      'groupadd', 'internal-sftp', 'sftp-server'):
                cmd += ['-t', t]
            if self.since:
                cmd += ['--since', dt.datetime.fromtimestamp(self.since).strftime('%Y-%m-%d %H:%M:%S')]
            try:
                out = subprocess.run(cmd, capture_output=True, text=True, errors='replace', timeout=300).stdout
                before = len(self.events)
                self.auth_lines(out.splitlines(), time.time(), 'journalctl')
                self.has_auth = True
                self.source('journalctl (sshd, sudo, su, useradd …)', 'SSH/계정', before)
            except (OSError, subprocess.SubprocessError) as ex:
                self.notes.append(f'journalctl 실행 실패: {ex}')
        if not self.has_auth:
            self.notes.append('auth.log / secure 로그가 없습니다. 삭제됐거나 journald 만 쓰는 시스템일 수 있습니다.')

    SSH_RX = [
        ('login_ok', re.compile(r'^Accepted (?P<method>\S+) for (?P<user>\S+) from (?P<ip>\S+) port (?P<port>\d+)(?: ssh2(?:: (?P<key>.+))?)?')),
        ('login_fail', re.compile(r'^Failed (?P<method>\S+) for (?P<invalid>invalid user )?(?P<user>\S*) from (?P<ip>\S+) port (?P<port>\d+)')),
        ('invalid', re.compile(r'^Invalid user (?P<user>\S*) from (?P<ip>\S+)')),
        ('sess_open', re.compile(r'^pam_unix\(sshd:session\): session opened for user (?P<user>[^\s(]+)')),
        ('sess_close', re.compile(r'^pam_unix\(sshd:session\): session closed for user (?P<user>\S+)')),
        ('disconnect', re.compile(r'^(?:Disconnected from|Received disconnect from|Connection closed by|Connection reset by) '
                                  r'(?:(?:authenticating|invalid) )?(?:user (?P<user>\S+) )?(?P<ip>[0-9a-fA-F:.]+)')),
        ('sftp_req', re.compile(r'^subsystem request for (?P<sub>\S+)(?: by user (?P<user>\S+))?')),
        ('maxauth', re.compile(r'(?:maximum authentication attempts exceeded for|PAM \d+ more authentication failures;)'
                               r'.*?(?:user[= ](?P<user>\S+))?.*?(?:from |rhost=)(?P<ip>[0-9a-fA-F:.]+)')),
    ]
    SUDO_RX = re.compile(r'^\s*(?P<user>\S+)\s*:\s*(?:(?P<fail>[^;]*?)\s*;\s*)?TTY=(?P<tty>\S+)\s*;\s*PWD=(?P<pwd>.*?)\s*;'
                         r'\s*USER=(?P<runas>\S+)\s*;(?:.*?;)?\s*COMMAND=(?P<cmd>.*)$')
    SFTP_SESS = re.compile(r'^session (?P<oc>opened|closed) for local user (?P<user>\S+) from \[(?P<ip>[^\]]+)\]')
    SFTP_CLOSE = re.compile(r'^close "(?P<path>.*)" bytes read (?P<r>\d+) written (?P<w>\d+)')
    SFTP_OP = re.compile(r'^(?P<op>remove|rename|mkdir|rmdir|symlink)(?: name)? "(?P<path>[^"]*)"(?: "(?P<to>[^"]*)")?')

    def auth_lines(self, lines, ref, src):
        for i, line in enumerate(lines, 1):
            line = line.rstrip('\n')
            m = SYSLOG_RE.match(line)
            if not m:
                continue
            ts = self.ts_bsd(m['bsd'], ref) if m['bsd'] else self.ts_iso(m['iso'])
            if ts is None:
                continue
            host, prog, pid, msg = m['host'], m['prog'], m['pid'], m['msg']
            self.hosts[host] += 1
            base = dict(host=host, src=src, line=i, raw=line, pid=pid)
            if prog == 'sshd':
                self.sshd_line(ts, msg, base)
            elif prog == 'sudo':
                self.sudo_line(ts, msg, base)
            elif prog == 'su' or msg.startswith('pam_unix(su'):
                self.su_line(ts, msg, base)
            elif prog in ('useradd', 'usermod', 'userdel', 'groupadd', 'passwd', 'chpasswd', 'chage', 'gpasswd'):
                self.acct_line(ts, prog, msg, base)
            elif prog in ('internal-sftp', 'sftp-server'):
                self.sftp_line(ts, msg, base)

    def sshd_line(self, ts, msg, base):
        for kind, rx in self.SSH_RX:
            m = rx.match(msg) if kind != 'maxauth' else rx.search(msg)
            if not m:
                continue
            g = m.groupdict()
            ip = clean_ip(g.get('ip'))
            user = g.get('user')
            if kind == 'login_ok':
                sev = 'med' if is_private(ip) else 'high'
                self.add(ts, 'auth', sev, f'SSH 로그인 성공 ({g["method"]})', kind=kind, user=user, ip=ip,
                         method=g['method'], detail=g.get('key'), **base)
            elif kind == 'login_fail':
                inv = ' — 존재하지 않는 계정' if g.get('invalid') else ''
                self.add(ts, 'auth', 'low', f'SSH 로그인 실패 ({g["method"]}){inv}', kind=kind, user=user, ip=ip, **base)
            elif kind == 'invalid':
                self.add(ts, 'auth', 'info', '존재하지 않는 계정으로 접속 시도', kind=kind, user=user, ip=ip, **base)
            elif kind == 'maxauth':
                self.add(ts, 'auth', 'low', '인증 시도 횟수 초과', kind=kind, user=user, ip=ip, **base)
            elif kind == 'sess_open':
                self.add(ts, 'session', 'info', 'SSH 세션 시작', kind=kind, user=user, **base)
            elif kind == 'sess_close':
                self.add(ts, 'session', 'info', 'SSH 세션 종료', kind=kind, user=user, **base)
            elif kind == 'disconnect':
                self.add(ts, 'session', 'info', '연결 종료', kind=kind, user=user, ip=ip, **base)
            elif kind == 'sftp_req':
                self.add(ts, 'transfer', 'med', f'SSH 서브시스템 요청: {g["sub"]} (파일 전송 세션)', kind=kind, user=user, **base)
            return

    def sudo_line(self, ts, msg, base):
        m = self.SUDO_RX.match(msg)
        if not m:
            return
        if m['fail']:
            self.add(ts, 'privesc', 'med', f'sudo 실패: {m["fail"]}', kind='sudo_fail', user=m['user'],
                     cmd=m['cmd'], tags=['sudo'], **base)
            return
        e = self.cmd_event(ts, m['cmd'], m['user'], via='sudo', cwd=m['pwd'], runas=m['runas'], **base)
        if e and m['runas'] != 'root':
            e['tags'].append(f'실행계정={m["runas"]}')

    def su_line(self, ts, msg, base):
        m = re.search(r'session opened for user (\S+?)(?:\(uid=\d+\))? by (\S+?)(?:\(uid=\d+\))?$', msg)
        if m:
            self.add(ts, 'privesc', 'med', f'su 로 계정 전환: {m[2]} → {m[1]}', kind='su', user=m[2], **base)
            return
        if 'FAILED' in msg or 'authentication failure' in msg:
            self.add(ts, 'privesc', 'low', 'su 실패', kind='su_fail', **base)

    def acct_line(self, ts, prog, msg, base):
        if prog == 'useradd' and 'new user' in msg:
            m = re.search(r'name=([^,\s]+).*?UID=(\d+)', msg)
            name, uid = (m[1], m[2]) if m else ('?', '?')
            if uid == '0':
                self.add(ts, 'persist', 'crit', f'UID 0 백도어 계정 생성: {name}', kind='acct', target=name, **base)
            else:
                self.add(ts, 'persist', 'high', f'계정 생성: {name} (UID {uid})', kind='acct', target=name, **base)
        elif 'password changed' in msg:
            m = re.search(r'password changed for (\S+)', msg)
            self.add(ts, 'persist', 'high', f'비밀번호 변경: {m[1] if m else "?"}', kind='acct', **base)
        elif prog in ('usermod', 'gpasswd') and re.search(r'add .* to (?:group|shadow group) .*(sudo|wheel|root|admin)', msg):
            self.add(ts, 'persist', 'crit', f'관리자 그룹 추가: {msg}', kind='acct', **base)
        elif prog in ('usermod', 'userdel', 'groupadd', 'chage'):
            self.add(ts, 'persist', 'med', f'{prog}: {msg}', kind='acct', **base)

    def sftp_line(self, ts, msg, base):
        pid = base['pid']
        m = self.SFTP_SESS.match(msg)
        if m:
            if m['oc'] == 'opened':
                self.sftp_pids[pid] = (m['user'], clean_ip(m['ip']))
            return
        user, ip = self.sftp_pids.get(pid, (None, None))
        m = self.SFTP_CLOSE.match(msg)
        if m:
            r, w = int(m['r']), int(m['w'])
            if r > 0:
                self.add(ts, 'transfer', 'crit', f'SFTP 다운로드 (서버 → 외부 유출) {human_bytes(r)}', kind='sftp_xfer',
                         user=user, ip=ip, path=m['path'], bytes=r, cmd=m['path'], **base)
            if w > 0:
                self.add(ts, 'transfer', 'high', f'SFTP 업로드 (외부 → 서버 반입) {human_bytes(w)}', kind='sftp_xfer',
                         user=user, ip=ip, path=m['path'], bytes=w, cmd=m['path'], **base)
            return
        m = self.SFTP_OP.match(msg)
        if m:
            target = m['path'] + (f' → {m["to"]}' if m['to'] else '')
            self.add(ts, 'transfer', 'med', f'SFTP {m["op"]}', kind='sftp_op', user=user, ip=ip, cmd=target, **base)

    # ── 명령 이벤트 공통 ──
    VIA = {'history': '셸 히스토리', 'audit': 'auditd', 'sudo': 'sudo'}

    def cmd_event(self, ts, cmd, user, via, **kw):
        cmd = cmd.strip()
        if not cmd:
            return None
        cat, sev, labels = classify(cmd)
        msg = labels[0] if labels else '명령 실행'
        if len(labels) > 1 and labels[0] == '파일 전송':
            msg = labels[1]
        return self.add(ts, cat, sev, msg, cmd=cmd, user=user, via=via,
                        tags=[self.VIA[via]] + [l for l in labels if l != msg], **kw)

    # ── auditd ──
    def scan_audit(self):
        noise = {'unix_chkpwd', 'sshd', 'run-parts', 'dircolors', 'lesspipe', 'basename', 'dirname',
                 'locale-check', 'tput', 'groups', 'update-motd', '50-motd-news', 'landscape-sysinfo'}
        for p in self.paths('var/log/audit/audit.log*'):
            f = self.safe_open(p)
            if not f:
                continue
            before = len(self.events)
            src = self.rel(p)
            recs = {}
            with f:
                for i, line in enumerate(f, 1):
                    m = AUDIT_HDR.search(line)
                    if not m:
                        continue
                    key = (m['ts'], m['serial'])
                    r = recs.get(key)
                    if r is None:
                        r = recs[key] = {'ts': float(m['ts']), 'line': i, 'raw': [], 'types': {}}
                    r['raw'].append(line.rstrip('\n'))
                    r['types'].setdefault(m['type'], audit_kv(m['body']))
            for r in recs.values():
                t = r['types']
                if 'EXECVE' in t:
                    sc = t.get('SYSCALL', {})
                    auid = sc.get('auid')
                    if (auid is None or auid in UNSET_AUID) and not self.audit_all:
                        continue
                    ex = t['EXECVE']
                    try:
                        argc = int(ex.get('argc', '0'))
                    except ValueError:
                        argc = 0
                    args = [audit_str(ex[f'a{n}']) for n in range(argc) if f'a{n}' in ex]
                    if not args:
                        continue
                    if os.path.basename(args[0]) in noise:
                        continue
                    user = audit_str(sc.get('AUID'), False) or self.uname(auid) or f'uid={sc.get("uid")}'
                    real = self.uname(sc.get('uid'))
                    e = self.cmd_event(r['ts'], shell_join(args), user, via='audit', src=src, line=r['line'],
                                       raw='\n'.join(r['raw']), ses=sc.get('ses'), pid=sc.get('pid'),
                                       cwd=audit_str(t.get('CWD', {}).get('cwd')), argv0=args[0],
                                       exe=audit_str(sc.get('exe'), False))
                    if e and real and real != user:
                        e['tags'].append(f'실행계정={real}')
                elif 'USER_LOGIN' in t:
                    k = t['USER_LOGIN']
                    ip = clean_ip(audit_str(k.get('addr'), False))
                    if not ip or ip == '?':
                        continue
                    user = audit_str(k.get('acct')) or self.uname(k.get('auid')) or self.uname(k.get('id'))
                    res = audit_str(k.get('res'), False)
                    if res == 'success':
                        self.add(r['ts'], 'session', 'info', 'audit 로그인 기록', kind='audit_login', user=user, ip=ip,
                                 ses=k.get('ses'), pid=k.get('pid'), src=src, line=r['line'], raw='\n'.join(r['raw']))
                    else:
                        self.add(r['ts'], 'auth', 'low', 'audit 로그인 실패 기록', kind='audit_fail', user=user, ip=ip,
                                 src=src, line=r['line'], raw='\n'.join(r['raw']))
            self.source(src, 'auditd', before)

    # ── 셸/DB 클라이언트 히스토리 ──
    def scan_history(self):
        pats = []
        for home in ('root', 'home/*', 'var/lib/*', 'srv/*'):
            for n in ('.bash_history', '.zsh_history', '.sh_history', '.ash_history', '.history',
                      '.mysql_history', '.psql_history'):
                pats.append(f'{home}/{n}')
        for p in self.paths(*pats):
            rp = self.rel(p)
            parts = rp.strip('/').split('/')
            user = 'root' if parts[0] == 'root' else parts[1] if len(parts) > 2 else parts[0]
            if parts[0] == 'var':  # /var/lib/postgresql 등 서비스 계정
                user = {'postgresql': 'postgres', 'pgsql': 'postgres'}.get(parts[2], parts[2])
            f = self.safe_open(p)
            if not f:
                continue
            before = len(self.events)
            dbhist = p.endswith(('.mysql_history', '.psql_history'))
            with f:
                pending = None
                for i, line in enumerate(f, 1):
                    line = line.rstrip('\n')
                    s = line.strip()
                    if not s:
                        continue
                    mt = re.fullmatch(r'#(\d{9,11})', s)
                    if mt:
                        pending = int(mt.group(1))
                        continue
                    mz = re.match(r'^: (\d{9,11}):\d+;(.*)$', line)
                    ts, cmd = (int(mz.group(1)), mz.group(2)) if mz else (pending, line)
                    pending = None
                    if dbhist:
                        self.db_history(ts, cmd.replace('\\040', ' '), user, rp, i, line)
                    else:
                        self.cmd_event(ts, cmd, user, via='history', src=rp, line=i, raw=line)
            self.source(rp, 'DB 클라이언트 기록' if dbhist else '셸 히스토리', before)

    def db_history(self, ts, sql, user, src, i, raw):
        if re.search(r'(?i)into\s+(?:out|dump)file|\bcopy\b.+\bto\b|load_file\s*\(|pg_read_file', sql):
            sev, msg = 'crit', 'SQL 로 파일 쓰기/읽기 (덤프 의심)'
        elif re.search(r'(?i)select\s+\*\s+from\s+\S*(user|member|customer|account|pay|card|order)', sql):
            sev, msg = 'med', '민감 테이블 조회'
        elif re.search(r'(?i)\b(drop|truncate|delete\s+from|grant|create\s+user|alter\s+user)\b', sql):
            sev, msg = 'high', '파괴적/권한 변경 SQL'
        else:
            sev, msg = 'info', 'DB 클라이언트 명령'
        self.add(ts, 'db', sev, msg, cmd=sql, user=user, via='history', src=src, line=i, raw=raw, tags=['DB 히스토리'])

    # ── wtmp / btmp ──
    UTMP = struct.Struct('<hxxi32s4s32s256shhiii4i20s')

    def scan_wtmp(self):
        for p in self.paths('var/log/wtmp*', 'var/log/btmp*'):
            rp = self.rel(p)
            try:
                data = gzip.open(p, 'rb').read() if p.endswith('.gz') else open(p, 'rb').read()
            except PermissionError:
                self.notes.append(f'읽기 권한 없음: {rp} — sudo 로 실행하세요')
                continue
            except OSError:
                continue
            if len(data) % self.UTMP.size:
                self.notes.append(f'{rp} 크기가 레코드 단위({self.UTMP.size}B)로 나누어지지 않음 — 변조/손상 의심')
            before = len(self.events)
            is_btmp = 'btmp' in os.path.basename(p)
            agg = {}
            for n in range(len(data) // self.UTMP.size):
                rec = self.UTMP.unpack_from(data, n * self.UTMP.size)
                typ, pid, tty, user, host, sec = rec[0], rec[1], rec[2], rec[4], rec[5], rec[9]
                dec = lambda b: b.split(b'\0', 1)[0].decode('utf-8', 'replace')
                tty, user, host = dec(tty), dec(user), dec(host)
                ip = clean_ip(host) if host and not host.startswith(':') else None
                if is_btmp:
                    if not ip:
                        continue
                    a = agg.setdefault((ip, user), {'n': 0, 'first': sec, 'last': sec, 'rec': n})
                    a['n'] += 1
                    a['first'], a['last'] = min(a['first'], sec), max(a['last'], sec)
                elif typ == 7 and user:
                    self.add(sec, 'session', 'info', f'로그인 기록 (wtmp, {tty})', kind='wtmp_login', user=user, ip=ip,
                             tty=tty, pid=str(pid), src=rp, line=n + 1)
                elif typ == 8:
                    self.add(sec, 'session', 'info', f'로그아웃 기록 (wtmp, {tty})', kind='wtmp_logout', tty=tty,
                             src=rp, line=n + 1, hidden=True)
            per_ip = {}
            for (ip, user), a in agg.items():
                b = per_ip.setdefault(ip, {'n': 0, 'first': a['first'], 'last': a['last'], 'rec': a['rec'], 'users': Counter()})
                b['n'] += a['n']
                b['users'][user] += a['n']
                b['first'], b['last'] = min(b['first'], a['first']), max(b['last'], a['last'])
                b['rec'] = min(b['rec'], a['rec'])
            for ip, b in per_ip.items():
                users = b['users'].most_common()
                self.add(b['first'], 'auth', 'med' if b['n'] >= 10 else 'low',
                         f'로그인 실패 {b["n"]}회 (btmp, 계정 {len(users)}개)', kind='btmp', ip=ip, count=b['n'],
                         users=users, cmd=', '.join(f'{u}({n})' for u, n in users[:15]), until=b['last'],
                         src=rp, line=b['rec'] + 1)
            self.source(rp, 'btmp' if is_btmp else 'wtmp', before)

    # ── MySQL general log ──
    MYSQL_RX = re.compile(r'^(?:(?P<ts>\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z?|\d{6}\s+\d{1,2}:\d\d:\d\d)\s+|\s+)'
                          r'(?P<id>\d+)\s(?P<cmd>Connect|Query|Quit|Init DB|Field List|Execute|Prepare)\s*(?P<arg>.*)$')

    def scan_mysql(self):
        files = self.paths('var/log/mysql/*.log*', 'var/log/mysql*.log*', 'var/log/mariadb/*.log*', 'var/lib/mysql/*.log')
        for p in files:
            f = self.safe_open(p)
            if not f:
                continue
            rp = self.rel(p)
            before = len(self.events)
            conns = {}
            cur_ts = None

            def flush(cid):
                c = conns.pop(cid, None)
                if not c or not (c['tables'] or c['snapshot']):
                    return
                tabs = c['tables']
                listed = ', '.join(tabs[:12]) + (f' 외 {len(tabs) - 12}개' if len(tabs) > 12 else '')
                self.add(c['dump_ts'] or c['ts'], 'db', 'crit',
                         f'mysqldump 덤프 패턴 감지 — 테이블 {len(tabs)}개' + (f' ({", ".join(c["dbs"])})' if c['dbs'] else ''),
                         kind='mysql_dump', user=c['user'], ip=c['ip'], cmd=listed, src=rp, line=c['line'],
                         raw='\n'.join(c['raw'][:40]), tags=['MySQL general log', f'conn {cid}'])

            with f:
                for i, line in enumerate(f, 1):
                    m = self.MYSQL_RX.match(line.rstrip('\n'))
                    if not m:
                        continue
                    if m['ts']:
                        if 'T' in m['ts']:
                            cur_ts = self.ts_iso(m['ts'], tz=dt.timezone.utc)
                        else:
                            try:
                                cur_ts = dt.datetime.strptime(re.sub(r'\s+', ' ', m['ts']), '%y%m%d %H:%M:%S') \
                                    .replace(tzinfo=self.tz).timestamp()
                            except ValueError:
                                pass
                    cid, cmd, arg = m['id'], m['cmd'], m['arg'].strip()
                    raw = line.rstrip('\n')
                    if cmd == 'Connect':
                        flush(cid)
                        mc = re.match(r"(?P<u>[^@\s]+)@(?P<h>\S+)(?: on (?P<db>\S*))?", arg)
                        if 'Access denied' in arg:
                            ma = re.search(r"user '([^']*)'@'([^']*)'", arg)
                            self.add(cur_ts, 'db', 'low', 'MySQL 접속 거부', kind='mysql_denied',
                                     user=ma[1] if ma else None, ip=clean_ip(ma[2]) if ma else None,
                                     src=rp, line=i, raw=raw, tags=['MySQL general log'])
                            continue
                        u, h = (mc['u'], mc['h']) if mc else (None, None)
                        ip = None if h in (None, 'localhost', '127.0.0.1', '::1') else clean_ip(h)
                        conns[cid] = {'user': u, 'ip': ip, 'ts': cur_ts, 'line': i, 'tables': [], 'dbs': [],
                                      'snapshot': False, 'dump_ts': None, 'raw': [raw]}
                        self.add(cur_ts, 'db', 'low' if ip else 'info', f'MySQL 접속: {u}@{h}', kind='mysql_conn',
                                 user=u, ip=ip, src=rp, line=i, raw=raw, tags=['MySQL general log'])
                        continue
                    c = conns.setdefault(cid, {'user': None, 'ip': None, 'ts': cur_ts, 'line': i, 'tables': [], 'dbs': [],
                                               'snapshot': False, 'dump_ts': None, 'raw': []})
                    if len(c['raw']) < 200:
                        c['raw'].append(raw)
                    if cmd == 'Quit':
                        flush(cid)
                    elif cmd == 'Init DB':
                        c['dbs'].append(arg)
                    elif cmd == 'Query':
                        if re.search(r'SQL_NO_CACHE', arg):
                            mt = re.search(r'FROM\s+`?([\w$]+)`?(?:\.`?([\w$]+)`?)?', arg, re.I)
                            if mt:
                                c['tables'].append(mt[2] or mt[1])
                                c['dump_ts'] = c['dump_ts'] or cur_ts
                        elif re.search(r'WITH CONSISTENT SNAPSHOT|SET @@SQL_MODE\s*=\s*\'\'', arg):
                            c['snapshot'] = True
                            c['dump_ts'] = c['dump_ts'] or cur_ts
                        if re.search(r'(?i)into\s+(?:out|dump)file|load_file\s*\(', arg):
                            self.add(cur_ts, 'db', 'crit', 'SQL 로 서버 파일 쓰기/읽기 (INTO OUTFILE / LOAD_FILE)',
                                     kind='mysql_outfile', user=c['user'], ip=c['ip'], cmd=arg, src=rp, line=i, raw=raw,
                                     tags=['MySQL general log'])
            for cid in list(conns):
                flush(cid)
            if len(self.events) > before:
                self.source(rp, 'MySQL', before)

    # ── PostgreSQL ──
    PG_RX = re.compile(r'^(?P<ts>\d{4}-\d\d-\d\d \d\d:\d\d:\d\d(?:\.\d+)?)(?:\s+(?P<tz>[A-Za-z]{2,5}|[+-]\d\d(?::?\d\d)?))?'
                       r'\s+\[(?P<pid>\d+)\](?:-\d+)?\s*(?:(?P<user>[\w.\-\[\]]*)@(?P<db>[\w.\-\[\]]*)\s+)?'
                       r'(?P<lvl>LOG|STATEMENT|ERROR|FATAL|WARNING|DETAIL|HINT|PANIC):\s+(?P<msg>.*)$')

    def scan_postgres(self):
        files = self.paths('var/log/postgresql/*.log*', 'var/lib/pgsql/*/data/log/*.log', 'var/lib/pgsql/data/log/*.log',
                           'var/lib/postgresql/*/main/log/*.log', 'var/lib/pgsql/*/data/pg_log/*.log')
        for p in files:
            f = self.safe_open(p)
            if not f:
                continue
            rp = self.rel(p)
            before = len(self.events)
            conns = {}

            def flush(pid):
                c = conns.pop(pid, None)
                if not c or not (c['tables'] or c['dumpapp']):
                    return
                tabs = c['tables']
                what = f'{c["app"]} 실행' if c['dumpapp'] else 'COPY TO 대량 추출'
                self.add(c['dump_ts'] or c['ts'], 'db', 'crit', f'PostgreSQL 덤프 감지 — {what}, 테이블 {len(tabs)}개'
                         + (f' (DB {c["db"]})' if c['db'] else ''), kind='pg_dump', user=c['user'], ip=c['ip'],
                         cmd=', '.join(tabs[:12]) or None, src=rp, line=c['line'], raw='\n'.join(c['raw'][:40]),
                         tags=['PostgreSQL 로그', f'pid {pid}'])

            with f:
                for i, line in enumerate(f, 1):
                    raw = line.rstrip('\n')
                    m = self.PG_RX.match(raw)
                    if not m:
                        continue
                    tz = None
                    if m['tz']:
                        if m['tz'].upper() in TZ_ABBR:
                            tz = dt.timezone(dt.timedelta(minutes=TZ_ABBR[m['tz'].upper()]))
                        elif m['tz'][0] in '+-':
                            tz = tz_from_str(m['tz'])
                    ts = self.ts_iso(m['ts'], tz=tz)
                    pid, msg = m['pid'], m['msg']
                    c = conns.get(pid)
                    if msg.startswith('connection received:'):
                        mh = re.search(r'host=(\S+)', msg)
                        h = mh[1] if mh else None
                        conns[pid] = {'ip': None if h in (None, '[local]', '127.0.0.1', '::1') else clean_ip(h),
                                      'user': None, 'db': None, 'app': None, 'dumpapp': False, 'tables': [],
                                      'ts': ts, 'dump_ts': None, 'line': i, 'raw': [raw]}
                        continue
                    if c is None:
                        c = conns[pid] = {'ip': None, 'user': m['user'], 'db': m['db'], 'app': None, 'dumpapp': False,
                                          'tables': [], 'ts': ts, 'dump_ts': None, 'line': i, 'raw': []}
                    if len(c['raw']) < 200:
                        c['raw'].append(raw)
                    if msg.startswith('connection authorized:'):
                        kv = dict(re.findall(r'(\w+)=(\S+)', msg))
                        c.update(user=kv.get('user'), db=kv.get('database'), app=kv.get('application_name'))
                        if c['app'] in ('pg_dump', 'pg_dumpall', 'pg_basebackup'):
                            c['dumpapp'] = True
                            c['dump_ts'] = ts
                        self.add(ts, 'db', 'low' if c['ip'] else 'info',
                                 f'PostgreSQL 접속: {c["user"]} → {c["db"]}' + (f' ({c["app"]})' if c['app'] else ''),
                                 kind='pg_conn', user=c['user'], ip=c['ip'], src=rp, line=i, raw=raw, tags=['PostgreSQL 로그'])
                    elif m['lvl'] == 'FATAL' and 'authentication failed' in msg:
                        mu = re.search(r'user "([^"]+)"', msg)
                        self.add(ts, 'db', 'low', 'PostgreSQL 인증 실패', kind='pg_fail', user=mu[1] if mu else None,
                                 ip=c['ip'], src=rp, line=i, raw=raw, tags=['PostgreSQL 로그'])
                    elif re.search(r'(?i)\bcopy\b', msg):
                        mt = re.search(r'(?i)copy\s+(?:\()?\s*([\w."]+)', msg)
                        if re.search(r"(?i)\bto\s+(?:'|program)", msg):
                            self.add(ts, 'db', 'crit', 'COPY TO 로 서버 파일 쓰기/명령 실행', kind='pg_copyfile',
                                     user=c['user'], ip=c['ip'], cmd=msg, src=rp, line=i, raw=raw, tags=['PostgreSQL 로그'])
                        elif re.search(r'(?i)\bto\s+stdout', msg) and mt:
                            c['tables'].append(mt[1])
                            c['dump_ts'] = c['dump_ts'] or ts
                    elif msg.startswith('disconnection:'):
                        flush(pid)
            for pid in list(conns):
                flush(pid)
            if len(self.events) > before:
                self.source(rp, 'PostgreSQL', before)

    # ── FTP ──
    def scan_ftp(self):
        for p in self.paths('var/log/xferlog*', 'var/log/vsftpd.log*', 'var/log/proftpd/xferlog*'):
            f = self.safe_open(p)
            if not f:
                continue
            rp = self.rel(p)
            before = len(self.events)
            with f:
                for i, line in enumerate(f, 1):
                    raw = line.rstrip('\n')
                    toks = raw.split()
                    mv = re.search(r'\[(?P<user>[^\]]+)\] (?P<res>OK|FAIL) (?P<op>DOWNLOAD|UPLOAD|LOGIN|DELETE|RENAME|MKDIR):'
                                   r' Client "(?P<ip>[^"]+)"(?:, "(?P<path>[^"]*)")?(?:, (?P<b>\d+) bytes)?', raw)
                    if mv and len(toks) >= 5:
                        ts = self.ftp_ts(toks[:5])
                        ip, op = clean_ip(mv['ip']), mv['op']
                        if op == 'LOGIN':
                            self.add(ts, 'auth', 'med' if mv['res'] == 'OK' else 'low', f'FTP 로그인 {mv["res"]}',
                                     kind='ftp_login', user=mv['user'], ip=ip, src=rp, line=i, raw=raw)
                        elif mv['res'] == 'OK':
                            down = op == 'DOWNLOAD'
                            size = f' {human_bytes(mv["b"])}' if mv['b'] else ''
                            self.add(ts, 'transfer', 'crit' if down else 'high',
                                     ('FTP 다운로드 (서버 → 외부 유출)' if down else f'FTP {op}') + size, kind='ftp_xfer',
                                     user=mv['user'], ip=ip, cmd=mv['path'], src=rp, line=i, raw=raw)
                    elif len(toks) >= 17 and toks[0] in ('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'):
                        # xferlog: date(5) time host bytes file type action dir mode user svc auth authuser status
                        ts = self.ftp_ts(toks[:5])
                        ip, size, direction, user = clean_ip(toks[6]), toks[7], toks[-9], toks[-5]
                        path = ' '.join(toks[8:-9])
                        down = direction == 'o'
                        self.add(ts, 'transfer', 'crit' if down else 'high',
                                 ('FTP 다운로드 (서버 → 외부 유출) ' if down else 'FTP 업로드 (외부 → 서버 반입) ')
                                 + human_bytes(size), kind='ftp_xfer', user=user, ip=ip, cmd=path, src=rp, line=i, raw=raw)
            self.source(rp, 'FTP', before)

    def ftp_ts(self, toks):
        try:
            return dt.datetime.strptime(' '.join(toks), '%a %b %d %H:%M:%S %Y').replace(tzinfo=self.tz).timestamp()
        except ValueError:
            return None

    # ───────────────────────── 상관분석 ─────────────────────────
    def merge_history_audit(self):
        """같은 명령이 셸 히스토리와 auditd 양쪽에 있으면 히스토리 쪽으로 합친다(파이프라인 원문 + 세션 정보)."""
        audits = defaultdict(list)
        for e in self.events:
            if e.get('via') == 'audit':
                audits[e['user']].append(e)
            elif e.get('via') == 'sudo' and e['ts'] is not None:
                e['argv0'] = e['cmd'].split()[0]
                audits[e['user']].append(e)
        for lst in audits.values():
            lst.sort(key=lambda e: e['ts'])
        drop = set()
        for h in self.events:
            if h.get('via') != 'history' or h.get('ts') is None or h['cat'] == 'db' and 'DB 히스토리' in h.get('tags', []):
                continue
            words = set(re.findall(r'[\w.\-]+', h['cmd']))
            for a in audits.get(h['user'], ()):
                if a['ts'] < h['ts'] - 2:
                    continue
                if a['ts'] > h['ts'] + 15:
                    break
                if id(a) in drop or os.path.basename(a['argv0']) not in words:
                    continue
                drop.add(id(a))
                if a.get('ses'):
                    h.setdefault('ses', a['ses'])
                label = 'auditd 확인' if a['via'] == 'audit' else 'sudo 로그 확인'
                if label not in h['tags']:
                    h['tags'].append(label)
                h['raw'] = h.get('raw', '') + f'\n── {a["via"]} ({a.get("src")}:{a.get("line")}) ──\n' + a.get('raw', '')
                if SEV_RANK[a['sev']] > SEV_RANK[h['sev']]:
                    h['sev'] = a['sev']
                for t in a['tags']:
                    if t.startswith('실행계정=') and t not in h['tags']:
                        h['tags'].append(t)
        self.events = [e for e in self.events if id(e) not in drop]

    def correlate(self):
        self.merge_history_audit()
        ev = self.events
        ev.sort(key=lambda e: (e['ts'] is None, e['ts'] or 0, e['seq']))

        sessions, by_pid, by_tty, ses_map = {}, {}, {}, {}
        fails = Counter()
        # btmp 는 auth 로그와 같은 실패를 중복 기록하므로, auth 로그에 실패가 없는 IP 에만 반영
        auth_fail_ips = {e.get('ip') for e in ev if e.get('kind') == 'login_fail'}
        for e in ev:
            if e.get('kind') == 'btmp' and e.get('ip') in auth_fail_ips:
                e['dup'] = True
                e['sev'] = 'low'
                e.setdefault('tags', []).append('auth 로그와 중복 집계 제외')

        def new_session(e, method, source):
            sid = f'S{len(sessions) + 1}'
            s = {'id': sid, 'user': e.get('user'), 'ip': e.get('ip'), 'host': e.get('host'), 'method': method,
                 'start': e['ts'], 'end': None, 'pid': e.get('pid'), 'tty': None, 'sources': [source],
                 'fails_before': fails[e.get('ip')] if e.get('ip') else 0}
            sessions[sid] = s
            return s

        def match_session(e, window=120):
            # audit 의 USER_LOGIN pid 는 sshd pid 와 같다. 그 외에는 같은 IP·근접 시각으로 맞춘다
            # (UID 0 별칭 계정은 audit 에서 root 로 보이므로 계정명은 우선순위로만 사용)
            if e.get('kind') == 'audit_login' and e.get('pid'):
                for (_, pid), s in by_pid.items():
                    if pid == e['pid'] and s['ip'] == e.get('ip'):
                        return s
            near = [s for s in sessions.values() if s['ip'] == e.get('ip') and abs(s['start'] - e['ts']) <= window]
            near.sort(key=lambda s: (s['user'] != e.get('user'), abs(s['start'] - e['ts'])))
            return near[0] if near else None

        backdoors = set(self.uid0_alias) | {e['target'] for e in ev if e.get('kind') == 'acct' and e.get('target')}

        # 1차: 로그인/세션 구간 구성
        for e in ev:
            k, ts = e.get('kind'), e['ts']
            if ts is None:
                continue
            if k == 'login_fail' or k == 'btmp' and not e.get('dup'):
                fails[e.get('ip')] += e.get('count', 1)
            elif k == 'login_ok':
                n = fails[e['ip']]
                if n >= 3:
                    e['sev'] = 'crit'
                    e['msg'] += f' — 직전 실패 {n}회 후 성공 (무차별 대입 성공 의심)'
                    e.setdefault('tags', []).append('무차별 대입 성공')
                if e.get('user') in backdoors:
                    e['sev'] = 'crit'
                    uid0 = e['user'] in self.uid0_alias
                    e['msg'] += ' — ' + ('UID 0 백도어 계정' if uid0 else '침해 중 생성된 계정') + '으로 로그인'
                    e.setdefault('tags', []).append('백도어 계정')
                if e.get('detail'):
                    e.setdefault('tags', []).append('키: ' + e['detail'])
                s = new_session(e, e.get('method'), 'auth')
                e['sid'] = s['id']
                if e.get('pid'):
                    by_pid[(e.get('host'), e['pid'])] = s
            elif k in ('sess_open', 'sess_close', 'disconnect', 'sftp_req') and e.get('pid'):
                s = by_pid.get((e.get('host'), e['pid']))
                if s:
                    e['sid'] = s['id']
                    e.setdefault('ip', s['ip'])
                    if k in ('sess_close', 'disconnect') and s['end'] is None:
                        s['end'] = ts
                    if k == 'sftp_req':
                        s['method'] = (s['method'] or '') + ' · sftp'
            elif k in ('audit_login', 'wtmp_login'):
                s = match_session(e)
                if s is None:
                    s = new_session(e, None, 'audit' if k == 'audit_login' else 'wtmp')
                elif ('audit' if k == 'audit_login' else 'wtmp') not in s['sources']:
                    s['sources'].append('audit' if k == 'audit_login' else 'wtmp')
                e['sid'] = s['id']
                if k == 'audit_login' and e.get('ses'):
                    ses_map[e['ses']] = s
                if k == 'wtmp_login':
                    s['tty'] = e.get('tty')
                    by_tty[e.get('tty')] = s
            elif k == 'wtmp_logout':
                s = by_tty.pop(e.get('tty'), None)
                if s and s['end'] is None:
                    s['end'] = ts

        slist = sorted(sessions.values(), key=lambda s: s['start'])

        def active(ts, user=None, ip=None):
            found = []
            for s in slist:
                if s['start'] > ts + 1:
                    break
                if user and s['user'] != user or ip and s['ip'] != ip:
                    continue
                if ts <= (s['end'] if s['end'] is not None else float('inf')) + 1:
                    found.append(s)
            return found

        # 2차: 명령/전송/DB 이벤트를 세션에 연결
        for e in ev:
            if e['ts'] is None or e.get('sid'):
                continue
            s, inferred = None, False
            if e.get('ses') and e['ses'] in ses_map:
                s = ses_map[e['ses']]
            elif e.get('via') or e.get('kind') in ('sftp_xfer', 'sftp_op', 'su', 'sudo_fail'):
                cand = active(e['ts'], e.get('user'), e.get('ip'))
                s = cand[-1] if cand else None
            elif e.get('kind') in ('acct',) or (e['cat'] == 'db' and not e.get('ip')):
                cand = [x for x in active(e['ts']) if x['ip'] and not is_private(x['ip'])]
                if len(cand) == 1:
                    s, inferred = cand[0], True
            if s:
                e['sid'] = s['id']
                if e.get('via') == 'audit' and s['user'] and e.get('user') != s['user']:
                    e.setdefault('tags', []).append(f'audit 계정={e["user"]}')
                    e['user'] = s['user']
                if not e.get('ip') and s['ip']:
                    e['ip'] = s['ip']
                    if inferred:
                        e['ip_inferred'] = True
                        e.setdefault('tags', []).append('세션 시간대로 추정')

        # 로그 변조 의심: wtmp/audit 에는 있는데 auth 로그에는 없는 외부 로그인
        if self.has_auth:
            auth_ts = [e['ts'] for e in ev if e.get('src', '').startswith(('/var/log/auth', '/var/log/secure', 'journal'))
                       and e['ts'] is not None]
            auth_ips = {e['ip'] for e in ev if e.get('kind') == 'login_ok'}
            if auth_ts:
                lo, hi = min(auth_ts), max(auth_ts)
                missing = {}
                for e in ev:
                    if e.get('kind') in ('audit_login', 'wtmp_login') and e.get('ip') and e['ip'] not in auth_ips \
                            and lo <= e['ts'] <= hi + 3600 and not is_private(e['ip']):
                        missing.setdefault(e['ip'], e)
                for ip, e in missing.items():
                    self.add(e['ts'], 'antiforensic', 'crit',
                             f'auth 로그 삭제/변조 의심 — {ip} 로그인이 {e["src"]} 에는 있으나 auth 로그에는 없음',
                             ip=ip, user=e.get('user'), sid=e.get('sid'), src=e['src'], line=e.get('line'))
                if missing:
                    ev = sorted(self.events, key=lambda e: (e['ts'] is None, e['ts'] or 0, e['seq']))

        # 세션 요약
        by_sid = defaultdict(list)
        for e in ev:
            if e.get('sid'):
                by_sid[e['sid']].append(e)
        for s in slist:
            es = by_sid.get(s['id'], [])
            s['cats'] = dict(Counter(e['cat'] for e in es if e['cat'] not in ('session',)))
            s['n'] = len(es)
            s['max_sev'] = max((e['sev'] for e in es), key=SEV_RANK.get, default='info')
            s['last'] = max((e['ts'] for e in es), default=s['start'])

        # 공격자 IP 프로필
        prof = {}
        for e in ev:
            ip = e.get('ip')
            if not ip or e.get('ip_inferred') and e['cat'] == 'auth':
                continue
            p = prof.get(ip)
            if p is None:
                p = prof[ip] = {'ip': ip, 'private': is_private(ip), 'fails': 0, 'ok': 0, 'tried': Counter(),
                                'ok_users': [], 'first': e['ts'], 'last': e['ts'], 'cats': Counter(),
                                'sev': Counter(), 'sessions': set()}
            k = e.get('kind')
            if k == 'login_fail':
                p['fails'] += 1
                if e.get('user'):
                    p['tried'][e['user']] += 1
            elif k == 'btmp' and not e.get('dup'):
                p['fails'] += e['count']
                for u, n in e.get('users', []):
                    p['tried'][u] += n
            elif k in ('invalid',) and e.get('user'):
                p['tried'][e['user']] += 0
            elif k == 'login_ok':
                p['ok'] += 1
                if e['user'] not in p['ok_users']:
                    p['ok_users'].append(e['user'])
            if e['ts'] is not None:
                p['first'] = e['ts'] if p['first'] is None else min(p['first'], e['ts'])
                p['last'] = e['ts'] if p['last'] is None else max(p['last'], e['ts'])
            if e['cat'] not in ('auth', 'session'):
                p['cats'][e['cat']] += 1
            p['sev'][e['sev']] += 1
            if e.get('sid'):
                p['sessions'].add(e['sid'])
        ips = []
        for p in prof.values():
            score = p['ok'] * 30 + (10 if p['fails'] >= 5 else 0) + min(p['fails'], 200) * 0.2 \
                + p['sev']['crit'] * 15 + p['sev']['high'] * 6 + p['sev']['med'] * 2
            if p['private']:
                score *= 0.5
            p.update(score=round(score, 1), tried=p['tried'].most_common(15), cats=dict(p['cats']),
                     sev=dict(p['sev']), sessions=sorted(p['sessions'], key=lambda x: int(x[1:])))
            ips.append(p)
        ips.sort(key=lambda p: -p['score'])

        out_events = []
        for e in ev:
            if e.get('hidden'):
                continue
            e = {k: v for k, v in e.items() if k not in ('seq', 'argv0', 'hidden', 'dup', 'users')}
            out_events.append(e)
        tss = [e['ts'] for e in out_events if e['ts'] is not None]
        off = self.tz.utcoffset(dt.datetime.now()).total_seconds() / 60
        return {
            'meta': {
                'generated': dt.datetime.now(self.tz).strftime('%Y-%m-%d %H:%M:%S'),
                'root': self.root, 'hosts': [h for h, _ in self.hosts.most_common(5)],
                'tz_offset_min': off, 'tz_label': 'UTC' + ('+' if off >= 0 else '-') + f'{int(abs(off)) // 60:02d}:{int(abs(off)) % 60:02d}',
                'range': [min(tss), max(tss)] if tss else None,
                'sources': self.sources, 'notes': self.notes, 'version': '1.0',
            },
            'cats': CATS,
            'events': out_events,
            'sessions': slist,
            'ips': ips,
        }


# ───────────────────────── 출력 ─────────────────────────
def render_html(data):
    payload = json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    return HTML_TEMPLATE.replace('__SECVIEW_DATA__', payload)


def serve(path, bind, port):
    directory, name = os.path.split(os.path.abspath(path))

    class H(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **kw):
            super().__init__(*a, directory=directory, **kw)

        def do_GET(self):
            if self.path in ('/', '/index.html'):
                self.path = '/' + name
            if self.path.split('?')[0] != '/' + name:
                self.send_error(404)
                return
            super().do_GET()

        def log_message(self, *a):
            pass

    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer((bind, port), H) as srv:
        print(f'[*] 뷰어: http://{bind}:{port}/   (Ctrl+C 로 종료)')
        if bind in ('127.0.0.1', 'localhost'):
            print(f'    원격 서버라면 내 PC 에서:  ssh -L {port}:127.0.0.1:{port} <서버>  후 브라우저로 접속')
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            pass


def main():
    ap = argparse.ArgumentParser(description='리눅스 침해사고 보안 로그 뷰어 (SSH 침입 / 명령 / DB 덤프 / 파일 전송)')
    ap.add_argument('--root', default='/', help='분석할 루트 디렉터리 (기본 /). 수집한 증거 폴더를 / 구조 그대로 지정')
    ap.add_argument('-o', '--output', default='secview_report.html', help='HTML 리포트 경로')
    ap.add_argument('--json', help='분석 결과 JSON 도 저장')
    ap.add_argument('--tz', type=tz_from_str, default=tz_from_str('local'),
                    help='syslog 시각의 시간대 (예: +09:00, UTC). 기본은 이 PC 시간대')
    ap.add_argument('--year', type=int, help='연도가 없는 syslog 의 연도 (기본: 파일 수정시각으로 추정)')
    ap.add_argument('--since', help='이 시각 이후만 (예: 2026-10-01 또는 2026-10-01T02:00)')
    ap.add_argument('--audit-all', action='store_true', help='auditd 에서 로그인 세션이 없는(데몬) 명령도 포함')
    ap.add_argument('--no-journal', action='store_true', help='auth 로그가 없어도 journalctl 을 쓰지 않음')
    ap.add_argument('--serve', nargs='?', const=8080, type=int, metavar='PORT', help='리포트를 HTTP 로 띄움 (기본 8080)')
    ap.add_argument('--bind', default='127.0.0.1', help='--serve 바인드 주소 (기본 127.0.0.1)')
    a = ap.parse_args()

    since = None
    if a.since:
        since = Analyzer('/', a.tz).ts_iso(a.since if 'T' in a.since or ' ' in a.since else a.since + 'T00:00:00')
        if since is None:
            ap.error('--since 형식: YYYY-MM-DD 또는 YYYY-MM-DDTHH:MM:SS')
    if not os.path.isdir(a.root):
        ap.error(f'디렉터리가 없습니다: {a.root}')
    if a.root == '/' and hasattr(os, 'geteuid') and os.geteuid() != 0:
        print('[!] root 가 아니면 auth.log / audit.log / btmp 를 못 읽을 수 있습니다. sudo 로 실행을 권장합니다.')

    t0 = time.time()
    an = Analyzer(a.root, a.tz, a.year, a.audit_all, not a.no_journal, since)
    data = an.run()
    with open(a.output, 'w', encoding='utf-8') as f:
        f.write(render_html(data))
    if a.json:
        with open(a.json, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=1)

    ev = data['events']
    cnt = Counter(e['cat'] for e in ev)
    crit = sum(1 for e in ev if e['sev'] == 'crit')
    print(f'[+] 로그 소스 {len(data["meta"]["sources"])}개, 이벤트 {len(ev)}건 ({time.time() - t0:.1f}s)')
    print(f'    치명 {crit} · SSH 인증 {cnt["auth"]} · DB {cnt["db"]} · 파일전송 {cnt["transfer"]} · '
          f'세션 {len(data["sessions"])} · IP {len(data["ips"])}')
    for n in data['meta']['notes']:
        print(f'[!] {n}')
    print(f'[+] 리포트: {os.path.abspath(a.output)}')
    if a.serve:
        serve(a.output, a.bind, a.serve)


# ───────────────────────── HTML 뷰어 ─────────────────────────
HTML_TEMPLATE = r'''<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>침해사고 로그 뷰어</title>
<style>
:root{
  --bg:#0b0f15;--panel:#121821;--panel2:#18202b;--line:#253041;--line2:#1d2633;
  --text:#e4eaf2;--muted:#8a97a8;--faint:#5c697b;--accent:#5b9dff;--accent-bg:#1a2b47;
  --crit:#ff4d5e;--high:#ff9a3d;--med:#e9c04a;--low:#58a6ff;--info:#6b7787;
  --crit-bg:rgba(255,77,94,.10);--high-bg:rgba(255,154,61,.07);
  --c-auth:#5b9dff;--c-session:#8f86f0;--c-cmd:#94a3b8;--c-db:#ff5f9e;--c-transfer:#ff9a3d;
  --c-persist:#c78bff;--c-antiforensic:#ff4d5e;--c-exec:#f97316;--c-privesc:#e9c04a;--c-recon:#34c47c;
  --mono:ui-monospace,"Cascadia Mono","D2Coding",Consolas,"SFMono-Regular",monospace;
  --sans:"Pretendard","Apple SD Gothic Neo","Malgun Gothic",system-ui,-apple-system,"Segoe UI",sans-serif;
  color-scheme:dark;
}
:root[data-theme=light]{
  --bg:#f5f7fa;--panel:#ffffff;--panel2:#f0f3f7;--line:#d9dfe7;--line2:#e7ebf0;
  --text:#18212d;--muted:#5d6b7c;--faint:#8b97a6;--accent:#2563eb;--accent-bg:#e5eeff;
  --crit:#d92638;--high:#d9690f;--med:#a77d00;--low:#2563eb;--info:#7a8594;
  --crit-bg:rgba(217,38,56,.07);--high-bg:rgba(217,105,15,.05);
  --c-auth:#2563eb;--c-session:#6d5ae6;--c-cmd:#64748b;--c-db:#d6337a;--c-transfer:#d9690f;
  --c-persist:#9a4ee0;--c-antiforensic:#d92638;--c-exec:#c2410c;--c-privesc:#a77d00;--c-recon:#15803d;
  color-scheme:light;
}
*{box-sizing:border-box}
html,body{margin:0}
body{background:var(--bg);color:var(--text);font:14px/1.5 var(--sans);-webkit-font-smoothing:antialiased}
a{color:var(--accent);cursor:pointer;text-decoration:none}
a:hover{text-decoration:underline}
code,.mono{font-family:var(--mono);font-size:12.5px}
button{font:inherit;color:inherit}
header{position:sticky;top:0;z-index:20;background:var(--bg);border-bottom:1px solid var(--line)}
.hwrap{max-width:1560px;margin:0 auto;padding:12px 20px 0;display:flex;flex-wrap:wrap;align-items:center;gap:6px 18px}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:16px;letter-spacing:-.01em}
.brand svg{color:var(--crit)}
.meta{color:var(--muted);font-size:12.5px;display:flex;gap:14px;flex-wrap:wrap}
.meta b{color:var(--text);font-weight:600}
.spacer{flex:1}
.iconbtn{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:5px 10px;cursor:pointer;font-size:12.5px;color:var(--muted)}
.iconbtn:hover{color:var(--text);border-color:var(--faint)}
nav{max-width:1560px;margin:0 auto;padding:0 20px;display:flex;gap:2px;overflow-x:auto}
nav button{background:none;border:0;border-bottom:2px solid transparent;padding:10px 14px;cursor:pointer;color:var(--muted);font-weight:600;white-space:nowrap}
nav button:hover{color:var(--text)}
nav button.on{color:var(--text);border-bottom-color:var(--accent)}
nav .n{font-weight:500;color:var(--faint);font-size:12px;margin-left:4px}
main{max-width:1560px;margin:0 auto;padding:18px 20px 60px}
h2{font-size:15px;margin:0 0 10px;font-weight:700;letter-spacing:-.01em}
h2 small{font-weight:500;color:var(--muted);font-size:12.5px;margin-left:6px}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px}
.grid2{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:16px;align-items:start}
@media (max-width:1000px){.grid2{grid-template-columns:1fr}}
.kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;margin-bottom:16px}
@media (max-width:1100px){.kpis{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:560px){.kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
.kpi{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:12px 14px;cursor:pointer;text-align:left;position:relative;overflow:hidden}
.kpi:hover{border-color:var(--faint)}
.kpi::before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--k)}
.kpi .l{color:var(--muted);font-size:12.5px}
.kpi .v{font-size:26px;font-weight:700;font-variant-numeric:tabular-nums;letter-spacing:-.02em;line-height:1.25}
.kpi .s{color:var(--faint);font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.kpi.zero .v{color:var(--faint)}
.notes{border:1px solid color-mix(in srgb,var(--high) 45%,transparent);background:var(--high-bg);border-radius:10px;padding:10px 14px;margin-bottom:16px;font-size:13px}
.notes div::before{content:"⚠ ";color:var(--high)}
/* 흐름 */
.flow{list-style:none;margin:0;padding:0;position:relative}
.flow li{display:grid;grid-template-columns:72px 14px minmax(0,1fr);gap:10px;padding:6px 0;cursor:pointer;border-radius:8px}
.flow li:hover{background:var(--panel2)}
.flow .t{font-family:var(--mono);font-size:12px;color:var(--muted);text-align:right;padding-top:2px}
.flow .t span{display:block;font-size:10.5px;color:var(--faint)}
.flow .dot{width:10px;height:10px;border-radius:50%;margin-top:6px;background:var(--c);box-shadow:0 0 0 3px color-mix(in srgb,var(--c) 22%,transparent)}
.flow .b{min-width:0}
.flow .m{font-weight:600}
.flow code{display:block;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:1px}
.flow .who{color:var(--faint);font-size:12px}
.daysep{font-size:11.5px;color:var(--faint);padding:8px 0 2px 96px;font-weight:600}
/* 배지 */
.sev{display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:600;white-space:nowrap;color:var(--s)}
.sev::before{content:"";width:8px;height:8px;border-radius:2px;background:var(--s)}
.sev.crit{--s:var(--crit)}.sev.high{--s:var(--high)}.sev.med{--s:var(--med)}.sev.low{--s:var(--low)}.sev.info{--s:var(--info)}
.cat{display:inline-block;font-size:11.5px;font-weight:600;padding:1px 7px;border-radius:5px;white-space:nowrap;
  color:var(--c);background:color-mix(in srgb,var(--c) 14%,transparent);border:1px solid color-mix(in srgb,var(--c) 30%,transparent)}
.tag{display:inline-block;font-size:11px;padding:0 6px;border-radius:4px;background:var(--panel2);color:var(--muted);border:1px solid var(--line);margin:1px 3px 1px 0;white-space:nowrap}
.tag.hot{color:var(--crit);border-color:color-mix(in srgb,var(--crit) 40%,transparent);background:var(--crit-bg)}
/* 툴바 */
.toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}
.search{flex:1 1 260px;min-width:0;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:7px 10px;color:var(--text);font:inherit}
.search:focus,select:focus{outline:2px solid color-mix(in srgb,var(--accent) 50%,transparent);border-color:var(--accent)}
select{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:6px 8px;color:var(--text);font:inherit}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}
.chip{border:1px solid var(--line);background:var(--panel);border-radius:999px;padding:3px 10px;cursor:pointer;font-size:12.5px;display:inline-flex;align-items:center;gap:6px;color:var(--muted)}
.chip i{width:8px;height:8px;border-radius:50%;background:var(--c);opacity:.35}
.chip.on{color:var(--text);border-color:color-mix(in srgb,var(--c) 55%,transparent);background:color-mix(in srgb,var(--c) 10%,var(--panel))}
.chip.on i{opacity:1}
.chip .n{color:var(--faint);font-size:11.5px;font-variant-numeric:tabular-nums}
.pill{display:inline-flex;align-items:center;gap:6px;background:var(--accent-bg);color:var(--text);border-radius:999px;padding:3px 6px 3px 10px;font-size:12.5px}
.pill button{border:0;background:none;cursor:pointer;color:var(--muted);font-size:14px;line-height:1;padding:0 3px}
.count{color:var(--muted);font-size:12.5px;margin-left:auto}
/* 표 */
.tablewrap{overflow-x:auto;border:1px solid var(--line);border-radius:12px;background:var(--panel)}
table{border-collapse:collapse;width:100%;min-width:980px}
th{position:sticky;top:0;background:var(--panel2);text-align:left;font-size:12px;color:var(--muted);font-weight:600;padding:8px 10px;border-bottom:1px solid var(--line);white-space:nowrap}
td{padding:7px 10px;border-bottom:1px solid var(--line2);vertical-align:top}
tr.ev{cursor:pointer}
tr.ev:hover td{background:var(--panel2)}
tr.ev.crit td{background:var(--crit-bg)}
tr.ev.crit td:first-child{box-shadow:inset 3px 0 0 var(--crit)}
tr.ev.high td:first-child{box-shadow:inset 3px 0 0 var(--high)}
tr.ev.open td{background:var(--panel2)}
td.t{font-family:var(--mono);font-size:12px;white-space:nowrap;color:var(--muted)}
td.m{min-width:320px}
td.m .msg{font-weight:600}
td.m code{display:block;margin-top:2px;white-space:pre-wrap;word-break:break-all;color:var(--text);opacity:.9}
td.src{font-family:var(--mono);font-size:11.5px;color:var(--faint);white-space:nowrap}
td.ipc{white-space:nowrap;font-family:var(--mono);font-size:12.5px}
.inferred{font-style:italic;opacity:.75}
tr.detail td{background:var(--bg);padding:12px 16px}
.kv{display:grid;grid-template-columns:110px minmax(0,1fr);gap:4px 12px;font-size:13px}
.kv dt{color:var(--muted)}
.kv dd{margin:0;min-width:0}
pre.raw{margin:0;padding:10px 12px;background:var(--panel2);border:1px solid var(--line);border-radius:8px;font:12px/1.55 var(--mono);white-space:pre-wrap;word-break:break-all;max-height:320px;overflow:auto}
.more{display:block;margin:12px auto 0;padding:8px 18px}
.empty{padding:40px;text-align:center;color:var(--muted)}
/* 공격자 */
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:12px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px 16px}
.card.hot{border-color:color-mix(in srgb,var(--crit) 55%,transparent)}
.card h3{margin:0;font:600 16px var(--mono);display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.badge{font:600 11px var(--sans);padding:1px 7px;border-radius:5px;background:var(--panel2);color:var(--muted);border:1px solid var(--line)}
.badge.red{color:var(--crit);border-color:color-mix(in srgb,var(--crit) 45%,transparent);background:var(--crit-bg)}
.score{height:4px;border-radius:2px;background:var(--line2);margin:10px 0 12px;overflow:hidden}
.score i{display:block;height:100%;background:linear-gradient(90deg,var(--high),var(--crit))}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px}
.stats div{background:var(--panel2);border-radius:8px;padding:6px 10px}
.stats b{display:block;font-size:18px;font-variant-numeric:tabular-nums}
.stats span{font-size:11.5px;color:var(--muted)}
.row{font-size:12.5px;color:var(--muted);margin:4px 0}
.row b{color:var(--text);font-weight:500}
.acts{display:flex;gap:8px;margin-top:12px}
/* 세션 */
.sess{background:var(--panel);border:1px solid var(--line);border-radius:12px;margin-bottom:10px;overflow:hidden}
.sess.hot{border-color:color-mix(in srgb,var(--crit) 50%,transparent)}
.sess>summary{list-style:none;cursor:pointer;padding:12px 16px;display:flex;flex-wrap:wrap;gap:6px 14px;align-items:center}
.sess>summary::-webkit-details-marker{display:none}
.sess>summary::before{content:"▸";color:var(--faint);transition:transform .15s}
.sess[open]>summary::before{transform:rotate(90deg)}
.sess .who{font:600 14px var(--mono)}
.sess .when{color:var(--muted);font-size:12.5px;font-family:var(--mono)}
.sess .body{border-top:1px solid var(--line);padding:6px 0}
.sline{display:grid;grid-template-columns:76px 96px minmax(0,1fr);gap:10px;padding:5px 16px;font-size:13px;cursor:pointer}
.sline:hover{background:var(--panel2)}
.sline .t{font:12px var(--mono);color:var(--muted)}
.sline code{white-space:pre-wrap;word-break:break-all}
.sline .mm{font-weight:600;margin-right:6px}
.srcs td{font-size:13px}
@media (max-width:640px){
  .hwrap,nav,main{padding-left:16px;padding-right:16px}
  .flow li{grid-template-columns:58px 12px minmax(0,1fr);gap:8px}
  .daysep{padding-left:78px}
  .sline{grid-template-columns:64px minmax(0,1fr)}
  .sline .c{display:none}
  .cards{grid-template-columns:1fr}
}
</style>
</head>
<body>
<header>
  <div class="hwrap">
    <div class="brand">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"/><path d="M12 8v5"/><path d="M12 16h.01"/></svg>
      침해사고 로그 뷰어
    </div>
    <div class="meta" id="meta"></div>
    <div class="spacer"></div>
    <button class="iconbtn" id="theme" title="테마 전환">테마</button>
  </div>
  <nav id="nav"></nav>
</header>
<main id="main"></main>

<script id="secview-data" type="application/json">__SECVIEW_DATA__</script>
<script>
(function(){
'use strict';
const D = JSON.parse(document.getElementById('secview-data').textContent);
const E = D.events, CATS = D.cats, M = D.meta;
E.forEach((e,i)=>{ e._i=i; });
const SEVS=['info','low','med','high','crit'], SEV_L={info:'정보',low:'낮음',med:'중간',high:'높음',crit:'치명'};
const sr = s => SEVS.indexOf(s);
const bySid = {}; E.forEach(e=>{ if(e.sid) (bySid[e.sid] ||= []).push(e); });
const SESS = {}; D.sessions.forEach(s=>SESS[s.id]=s);
const OFF = M.tz_offset_min;

const st = { view:'overview', cats:new Set(Object.keys(CATS)), minSev:0, q:'', ip:null, user:null, sid:null, limit:300, open:new Set(), hideNoise:true };
try{ const t=localStorage.getItem('secview-theme'); if(t) document.documentElement.dataset.theme=t; }catch(_){}

const $ = s=>document.querySelector(s);
const esc = s => String(s==null?'':s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function iso(ts){ return new Date((ts+OFF*60)*1000).toISOString(); }
function fmt(ts){ if(ts==null) return '시각 미상'; const s=iso(ts); return s.slice(0,10)+' '+s.slice(11,19); }
function hms(ts){ return ts==null?'—':iso(ts).slice(11,19); }
function day(ts){ return ts==null?'':iso(ts).slice(0,10); }
function dur(a,b){ if(a==null||b==null) return ''; let s=Math.max(0,Math.round(b-a)); const h=Math.floor(s/3600), m=Math.floor(s%3600/60); s%=60; return h?`${h}시간 ${m}분`:m?`${m}분 ${s}초`:`${s}초`; }
const catB = c => `<span class="cat" style="--c:var(--c-${c})">${esc(CATS[c]||c)}</span>`;
const sevB = s => `<span class="sev ${s}">${SEV_L[s]}</span>`;
const HOT = /유출|백도어|무차별|덤프|흔적|변조|UID 0/;
const tagsH = e => (e.tags||[]).map(t=>`<span class="tag${HOT.test(t)?' hot':''}">${esc(t)}</span>`).join('');
const ipH = e => e.ip ? `<a data-act="ip" data-v="${esc(e.ip)}" class="${e.ip_inferred?'inferred':''}" title="${e.ip_inferred?'세션 시간대로 추정한 IP':''}">${esc(e.ip)}</a>` : '';
const isNoise = e => e.sev==='info' && (e.cat==='session' || e.cat==='auth');

/* ── 헤더 ── */
const r = M.range;
$('#meta').innerHTML = [
  M.hosts.length?`호스트 <b>${esc(M.hosts.join(', '))}</b>`:'',
  r?`기간 <b>${fmt(r[0])}</b> ~ <b>${fmt(r[1])}</b> <span>(${esc(M.tz_label)})</span>`:'',
  `이벤트 <b>${E.length.toLocaleString()}</b>`,
  `생성 ${esc(M.generated)}`
].filter(Boolean).map(x=>`<span>${x}</span>`).join('');
$('#theme').onclick = ()=>{
  const cur = document.documentElement.dataset.theme || (matchMedia('(prefers-color-scheme: light)').matches?'light':'dark');
  const nt = cur==='dark'?'light':'dark'; document.documentElement.dataset.theme=nt;
  try{ localStorage.setItem('secview-theme', nt); }catch(_){}
};
if(!document.documentElement.dataset.theme && matchMedia('(prefers-color-scheme: light)').matches) document.documentElement.dataset.theme='light';

const VIEWS = [['overview','개요'],['timeline','타임라인',E.length],['ips','공격자 IP',D.ips.length],['sessions','세션',D.sessions.length],['sources','로그 소스',M.sources.length]];
function renderNav(){
  $('#nav').innerHTML = VIEWS.map(([k,l,n])=>`<button data-act="view" data-v="${k}" class="${st.view===k?'on':''}">${l}${n!=null?`<span class="n">${n.toLocaleString()}</span>`:''}</button>`).join('');
}

/* ── 필터 ── */
function searchText(e){ return e._s || (e._s = [e.msg,e.cmd,e.user,e.ip,e.raw,e.src,e.cwd,(e.tags||[]).join(' ')].join(' ').toLowerCase()); }
function filtered(){
  const q = st.q.trim().toLowerCase();
  return E.filter(e => st.cats.has(e.cat) && sr(e.sev)>=st.minSev && (!st.ip||e.ip===st.ip) && (!st.user||e.user===st.user)
    && (!st.sid||e.sid===st.sid) && (!st.hideNoise || st.ip || st.sid || !isNoise(e)) && (!q || searchText(e).includes(q)));
}
function go(view, f){
  Object.assign(st, {view, limit:300}, f||{}); render(); window.scrollTo(0,0);
}

/* ── 개요 ── */
function overview(){
  const ext = D.ips.filter(p=>p.ok>0 && !p.private);
  const fails = D.ips.reduce((a,p)=>a+p.fails,0);
  const cmds = E.filter(e=>e.via && e.cat!=='db' || e.via==='audit' || (e.via && e.cmd && e.cat==='db' && !(e.tags||[]).includes('DB 히스토리'))).length;
  const dbd = E.filter(e=>e.cat==='db' && e.sev==='crit').length;
  const xfer = E.filter(e=>e.cat==='transfer').length;
  const xferOut = E.filter(e=>e.cat==='transfer' && /유출/.test(e.msg+(e.tags||[]).join())).length;
  const pa = E.filter(e=>e.cat==='persist'||e.cat==='antiforensic').length;
  const K = [
    ['침입 성공 외부 IP', ext.length, ext.slice(0,3).map(p=>p.ip).join(', ')||'없음', '--crit', ()=>go('ips')],
    ['SSH 로그인 실패', fails, `${D.ips.filter(p=>p.fails>=5).length}개 IP 무차별 대입`, '--c-auth', ()=>go('timeline',{cats:new Set(['auth']),minSev:0})],
    ['실행 명령', cmds, '히스토리 · auditd · sudo', '--c-cmd', ()=>go('timeline',{cats:new Set(['cmd','recon','exec','privesc','persist','antiforensic','db','transfer']),q:'',minSev:0})],
    ['DB 덤프', dbd, 'mysqldump · pg_dump · OUTFILE', '--c-db', ()=>go('timeline',{cats:new Set(['db']),minSev:0})],
    ['파일 전송', xfer, `유출 의심 ${xferOut}건`, '--c-transfer', ()=>go('timeline',{cats:new Set(['transfer']),minSev:0})],
    ['지속성 · 흔적삭제', pa, '계정 · 키 · cron · history', '--c-persist', ()=>go('timeline',{cats:new Set(['persist','antiforensic']),minSev:0})],
  ];
  window._kpi = K.map(k=>k[4]);
  let h = `<div class="kpis">${K.map((k,i)=>`<button class="kpi${k[1]?'':' zero'}" style="--k:var(${k[3]})" data-act="kpi" data-v="${i}"><div class="l">${k[0]}</div><div class="v">${k[1].toLocaleString()}</div><div class="s">${esc(k[2])}</div></button>`).join('')}</div>`;
  if(M.notes.length) h += `<div class="notes">${M.notes.map(n=>`<div>${esc(n)}</div>`).join('')}</div>`;

  const key = E.filter(e=>sr(e.sev)>=3 && e.ts!=null);
  let lastDay='';
  const flow = key.slice(0,80).map(e=>{
    const d = day(e.ts); const sep = d!==lastDay ? `<div class="daysep">${d}</div>` : ''; lastDay=d;
    return sep+`<li data-act="ev" data-v="${e._i}" style="--c:var(--c-${e.cat})"><div class="t">${hms(e.ts)}</div><div class="dot"></div><div class="b">
      <div>${catB(e.cat)} <span class="m">${esc(e.msg)}</span></div>
      ${e.cmd?`<code>${esc(e.cmd)}</code>`:''}
      <div class="who">${[e.user, e.ip].filter(Boolean).map(esc).join(' · ')}${e.sid?` · 세션 ${esc(e.sid)}`:''} · ${esc(e.src||'')}</div></div></li>`;
  }).join('');
  h += `<div class="grid2"><section class="panel"><h2>공격 흐름 <small>위험도 높음 이상 ${key.length}건, 시간순</small></h2>
    ${key.length?`<ul class="flow">${flow}</ul>${key.length>80?`<a data-act="kpi-high" class="more iconbtn" style="text-align:center">전체 ${key.length}건 타임라인에서 보기</a>`:''}`:'<div class="empty">높은 위험도 이벤트가 없습니다.</div>'}</section>
    <section><div class="panel" style="margin-bottom:16px"><h2>위험 IP <small>상위 ${Math.min(6,D.ips.length)}</small></h2>${D.ips.slice(0,6).map(ipMini).join('')||'<div class="empty">IP 정보 없음</div>'}</div>
    <div class="panel"><h2>위험 세션</h2>${D.sessions.filter(s=>sr(s.max_sev)>=3).slice(0,8).map(sessMini).join('')||'<div class="empty">없음</div>'}</div></section></div>`;
  return h;
}
function ipMini(p){
  const max = D.ips[0].score||1;
  return `<div style="padding:8px 0;border-bottom:1px solid var(--line2)">
    <div style="display:flex;align-items:center;gap:8px"><a class="mono" data-act="ipcard" data-v="${esc(p.ip)}" style="font-weight:600">${esc(p.ip)}</a>
    ${p.private?'<span class="badge">내부</span>':''}${p.ok&&p.fails>=3?'<span class="badge red">무차별 대입 성공</span>':p.ok?'<span class="badge red">로그인 성공</span>':''}
    <span style="margin-left:auto;font-size:12px;color:var(--muted)">실패 ${p.fails} · 성공 ${p.ok}</span></div>
    <div class="score" style="margin:6px 0 0"><i style="width:${Math.max(3,p.score/max*100)}%"></i></div></div>`;
}
function sessMini(s){
  return `<div style="padding:7px 0;border-bottom:1px solid var(--line2);cursor:pointer" data-act="sess" data-v="${s.id}">
    <div><b class="mono">${esc(s.user||'?')}@${esc(s.ip||'local')}</b> ${sevB(s.max_sev)}</div>
    <div style="font-size:12px;color:var(--muted)">${fmt(s.start)} · ${dur(s.start, s.end ?? s.last)} · 이벤트 ${s.n}</div></div>`;
}

/* ── 타임라인 ── */
function timeline(){
  const cnt = {}; E.forEach(e=>cnt[e.cat]=(cnt[e.cat]||0)+1);
  const rows = filtered();
  const pills = [['ip','IP'],['user','사용자'],['sid','세션']].filter(([k])=>st[k]).map(([k,l])=>`<span class="pill">${l}: <b class="mono">${esc(st[k])}</b><button data-act="clr" data-v="${k}" aria-label="필터 해제">×</button></span>`).join('');
  let h = `<div class="toolbar">
    <input class="search" id="q" placeholder="검색: 명령어, IP, 계정, 파일 경로, 원본 로그…" value="${esc(st.q)}">
    <select id="sev">${SEVS.map((s,i)=>`<option value="${i}" ${st.minSev===i?'selected':''}>${i?SEV_L[s]+' 이상':'모든 위험도'}</option>`).join('')}</select>
    <label style="font-size:12.5px;color:var(--muted);display:flex;gap:5px;align-items:center"><input type="checkbox" id="noise" ${st.hideNoise?'checked':''}>접속 잡음 숨김</label>
    <button class="iconbtn" data-act="csv">CSV 내보내기</button></div>
  <div class="chips"><button class="chip" data-act="allcats" style="--c:var(--muted)">${st.cats.size===Object.keys(CATS).length?'모두 해제':'모두 선택'}</button>
    ${Object.keys(CATS).map(c=>`<button class="chip ${st.cats.has(c)?'on':''}" data-act="cat" data-v="${c}" style="--c:var(--c-${c})"><i></i>${esc(CATS[c])}<span class="n">${cnt[c]||0}</span></button>`).join('')}</div>
  <div class="toolbar">${pills}<span class="count">${rows.length.toLocaleString()}건${rows.length>st.limit?` 중 ${st.limit.toLocaleString()}건 표시`:''}</span></div>`;
  if(!rows.length) return h+`<div class="tablewrap"><div class="empty">조건에 맞는 이벤트가 없습니다.</div></div>`;
  h += `<div class="tablewrap"><table><thead><tr><th>시각 (${esc(M.tz_label)})</th><th>위험</th><th>분류</th><th>사용자</th><th>출발지 IP</th><th>내용</th><th>출처</th></tr></thead><tbody>`;
  h += rows.slice(0,st.limit).map(rowH).join('');
  h += `</tbody></table></div>`;
  if(rows.length>st.limit) h += `<button class="iconbtn more" data-act="more">더 보기 (+500)</button>`;
  return h;
}
function rowH(e){
  const open = st.open.has(e._i);
  return `<tr class="ev ${e.sev}${open?' open':''}" data-act="row" data-v="${e._i}">
    <td class="t">${fmt(e.ts)}</td><td>${sevB(e.sev)}</td><td>${catB(e.cat)}</td>
    <td>${e.user?`<a data-act="user" data-v="${esc(e.user)}">${esc(e.user)}</a>`:''}</td>
    <td class="ipc">${ipH(e)}</td>
    <td class="m"><div class="msg">${esc(e.msg)}</div>${e.cmd?`<code>${esc(e.cmd)}</code>`:''}<div>${tagsH(e)}</div></td>
    <td class="src">${esc(e.src||'')}${e.line?':'+e.line:''}</td></tr>`
    + (open?`<tr class="detail"><td colspan="7">${detailH(e)}</td></tr>`:'');
}
function detailH(e){
  const s = e.sid && SESS[e.sid];
  const kv = [
    ['출처', `<span class="mono">${esc(e.src||'')}${e.line?':'+e.line:''}</span>`],
    s?['세션', `<a data-act="sess" data-v="${s.id}">${esc(s.id)} — ${esc(s.user||'?')}@${esc(s.ip||'local')} (${fmt(s.start)} 시작)</a>`]:null,
    e.cwd?['작업 경로', `<span class="mono">${esc(e.cwd)}</span>`]:null,
    e.pid?['PID', `<span class="mono">${esc(e.pid)}</span>`]:null,
    e.exe?['실행 파일', `<span class="mono">${esc(e.exe)}</span>`]:null,
    e.ses?['audit 세션', `<span class="mono">ses=${esc(e.ses)}</span>`]:null,
    e.path?['파일', `<span class="mono">${esc(e.path)}</span>`]:null,
    e.count?['횟수', `${e.count}회${e.until?` (마지막 ${fmt(e.until)})`:''}`]:null,
    e.ip_inferred?['참고', '이 IP 는 로그에 직접 기록된 값이 아니라, 같은 시간대에 열려 있던 유일한 외부 SSH 세션으로 추정한 값입니다.']:null,
  ].filter(Boolean);
  return `<dl class="kv">${kv.map(([k,v])=>`<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>${e.raw?`<div style="margin-top:10px"><pre class="raw">${esc(e.raw)}</pre></div>`:''}`;
}
function csv(){
  const rows = filtered();
  const q = v => '"' + String(v==null?'':v).replace(/"/g,'""') + '"';
  const out = ['시각,위험,분류,사용자,IP,세션,내용,명령/대상,태그,출처'].concat(rows.map(e=>[fmt(e.ts),SEV_L[e.sev],CATS[e.cat],e.user,e.ip,e.sid,e.msg,e.cmd,(e.tags||[]).join(' | '),(e.src||'')+(e.line?':'+e.line:'')].map(q).join(',')));
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\ufeff'+out.join('\r\n')],{type:'text/csv'}));
  a.download = 'secview_events.csv'; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href), 1000);
}

/* ── 공격자 ── */
function ips(){
  if(!D.ips.length) return '<div class="panel empty">IP 가 기록된 이벤트가 없습니다.</div>';
  const max = D.ips[0].score||1;
  return `<div class="cards">${D.ips.map(p=>{
    const hot = p.ok && !p.private;
    const cats = Object.entries(p.cats).sort((a,b)=>b[1]-a[1]).map(([c,n])=>`${catB(c)} <span style="font-size:12px;color:var(--muted)">${n}</span>`).join(' ');
    return `<div class="card${hot?' hot':''}" id="ip-${esc(p.ip)}">
      <h3>${esc(p.ip)} ${p.private?'<span class="badge">내부망</span>':'<span class="badge">외부</span>'}${p.ok&&p.fails>=3?'<span class="badge red">무차별 대입 성공</span>':p.ok?'<span class="badge red">로그인 성공</span>':p.fails>=5?'<span class="badge">무차별 대입</span>':''}</h3>
      <div class="score" title="위험 점수 ${p.score}"><i style="width:${Math.max(2,p.score/max*100)}%"></i></div>
      <div class="stats"><div><b>${p.fails.toLocaleString()}</b><span>로그인 실패</span></div><div><b style="${p.ok?'color:var(--crit)':''}">${p.ok}</b><span>로그인 성공</span></div><div><b>${p.sessions.length}</b><span>세션</span></div></div>
      ${p.ok_users.length?`<div class="row">성공 계정 <b class="mono" style="color:var(--crit)">${p.ok_users.map(esc).join(', ')}</b></div>`:''}
      ${p.tried.length?`<div class="row">시도 계정 <b class="mono">${p.tried.slice(0,8).map(([u,n])=>esc(u)+(n?`(${n})`:'')).join(', ')}${p.tried.length>8?' …':''}</b></div>`:''}
      <div class="row">최초 <b class="mono">${fmt(p.first)}</b></div><div class="row">최종 <b class="mono">${fmt(p.last)}</b></div>
      ${cats?`<div class="row" style="margin-top:8px">${cats}</div>`:''}
      <div class="acts"><button class="iconbtn" data-act="ip" data-v="${esc(p.ip)}">타임라인</button>${p.sessions.length?`<button class="iconbtn" data-act="ipsess" data-v="${esc(p.ip)}">세션 ${p.sessions.length}개</button>`:''}</div></div>`;
  }).join('')}</div>`;
}

/* ── 세션 ── */
function sessions(){
  let list = D.sessions;
  if(st.ip) list = list.filter(s=>s.ip===st.ip);
  if(!list.length) return '<div class="panel empty">세션 정보가 없습니다. (auth.log / wtmp / audit 의 로그인 기록으로 만듭니다)</div>';
  const head = st.ip?`<div class="toolbar"><span class="pill">IP: <b class="mono">${esc(st.ip)}</b><button data-act="clr" data-v="ip">×</button></span></div>`:'';
  return head + list.map(s=>{
    const es = (bySid[s.id]||[]).filter(e=>!isNoise(e) || e.kind==='login_ok');
    const hot = sr(s.max_sev)>=4;
    const cats = Object.entries(s.cats).filter(([c])=>c!=='auth').map(([c,n])=>`${catB(c)}<span style="font-size:12px;color:var(--muted);margin:0 6px 0 3px">${n}</span>`).join('');
    return `<details class="sess${hot?' hot':''}" id="sess-${s.id}" ${hot||st.sid===s.id?'open':''}>
      <summary><span class="mono" style="color:var(--faint)">${s.id}</span><span class="who">${esc(s.user||'?')}@${esc(s.ip||'local')}</span>${sevB(s.max_sev)}
      <span class="when">${fmt(s.start)} → ${s.end!=null?hms(s.end):'종료 기록 없음'} · ${dur(s.start, s.end ?? s.last)}</span>
      ${s.method?`<span class="badge">${esc(s.method)}</span>`:''}${s.fails_before>=3?`<span class="badge red">직전 실패 ${s.fails_before}회</span>`:''}
      <span style="font-size:12px;color:var(--faint)">근거: ${esc(s.sources.join(', '))}</span><span>${cats}</span></summary>
      <div class="body">${es.map(e=>`<div class="sline" data-act="ev" data-v="${e._i}"><span class="t">${hms(e.ts)}</span><span class="c">${catB(e.cat)}</span>
        <span><span class="mm" style="color:var(--${e.sev==='info'?'muted':e.sev})">${esc(e.msg)}</span>${e.cmd?`<code>${esc(e.cmd)}</code>`:''}</span></div>`).join('')||'<div class="empty">연결된 이벤트 없음</div>'}</div></details>`;
  }).join('');
}

/* ── 소스 ── */
function sources(){
  return `<div class="tablewrap"><table class="srcs" style="min-width:560px"><thead><tr><th>로그 파일</th><th>종류</th><th style="text-align:right">이벤트</th></tr></thead><tbody>
    ${M.sources.map(s=>`<tr><td class="mono">${esc(s.path)}</td><td>${esc(s.kind)}</td><td style="text-align:right;font-variant-numeric:tabular-nums">${s.events.toLocaleString()}</td></tr>`).join('')||'<tr><td colspan="3" class="empty">읽은 로그가 없습니다.</td></tr>'}
  </tbody></table></div>
  ${M.notes.length?`<div class="notes" style="margin-top:16px">${M.notes.map(n=>`<div>${esc(n)}</div>`).join('')}</div>`:''}
  <p style="color:var(--muted);font-size:12.5px;margin-top:16px">분석 루트: <span class="mono">${esc(M.root)}</span> · 시간대 ${esc(M.tz_label)} · secviewer ${esc(M.version)}</p>`;
}

/* ── 렌더 / 이벤트 ── */
function render(){
  renderNav();
  const v = {overview, timeline, ips, sessions, sources}[st.view];
  $('#main').innerHTML = v();
  if(st.view==='timeline'){
    const q = $('#q'); let t;
    q.oninput = ()=>{ clearTimeout(t); t=setTimeout(()=>{ st.q=q.value; st.limit=300; const pos=q.selectionStart; render(); const n=$('#q'); n.focus(); n.setSelectionRange(pos,pos); },160); };
    $('#sev').onchange = ev=>{ st.minSev=+ev.target.value; render(); };
    $('#noise').onchange = ev=>{ st.hideNoise=ev.target.checked; render(); };
  }
}
function openEvent(i){
  const e = E[i];
  st.open = new Set([i]);
  const f = {cats:new Set(Object.keys(CATS)), minSev:0, q:'', ip:null, user:null, sid:e.sid||null, hideNoise:!isNoise(e)};
  if(!e.sid){ f.ip = e.ip||null; }
  const rows = (Object.assign(st,f), filtered());
  st.limit = Math.max(300, rows.indexOf(e)+50);
  st.view='timeline'; render();
  const el = document.querySelector(`tr.ev[data-v="${i}"]`); if(el) el.scrollIntoView({block:'center'});
}
document.addEventListener('click', ev=>{
  const t = ev.target.closest('[data-act]'); if(!t) return;
  const a = t.dataset.act, v = t.dataset.v;
  if(a!=='row') ev.stopPropagation();
  switch(a){
    case 'view': go(v, v==='timeline'?{}:{ip:null,sid:null}); break;
    case 'kpi': window._kpi[+v](); break;
    case 'kpi-high': go('timeline',{minSev:3,cats:new Set(Object.keys(CATS)),ip:null,user:null,sid:null,q:''}); break;
    case 'cat': st.cats.has(v)?st.cats.delete(v):st.cats.add(v); st.limit=300; render(); break;
    case 'allcats': st.cats = st.cats.size===Object.keys(CATS).length?new Set():new Set(Object.keys(CATS)); render(); break;
    case 'ip': go('timeline',{ip:v,sid:null,cats:new Set(Object.keys(CATS))}); break;
    case 'user': go('timeline',{user:v}); break;
    case 'clr': st[v]=null; render(); break;
    case 'more': st.limit+=500; render(); break;
    case 'csv': csv(); break;
    case 'row': { const i=+v; st.open.has(i)?st.open.delete(i):st.open.add(i); const y=window.scrollY; render(); window.scrollTo(0,y); break; }
    case 'ev': openEvent(+v); break;
    case 'sess': go('sessions',{sid:v,ip:null}); setTimeout(()=>{ const el=document.getElementById('sess-'+v); if(el){ el.open=true; el.scrollIntoView({block:'start'}); window.scrollBy(0,-110);} },0); break;
    case 'ipsess': go('sessions',{ip:v}); break;
    case 'ipcard': go('ips'); setTimeout(()=>{ const el=document.getElementById('ip-'+v); if(el){ el.scrollIntoView({block:'center'}); el.style.outline='2px solid var(--accent)'; } },0); break;
  }
});
render();
})();
</script>
</body>
</html>
'''

if __name__ == '__main__':
    main()
